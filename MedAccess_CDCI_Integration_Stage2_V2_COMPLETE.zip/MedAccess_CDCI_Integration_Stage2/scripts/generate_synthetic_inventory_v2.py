#!/usr/bin/env python3
"""Generate reproducible, synthetic MedAccess inventory with products shared across pharmacies.

This generator creates a NEW SQLite file. It never edits an existing database.
All pharmacy, stock, price and timestamp values are synthetic demo data.
"""
import argparse, csv, random, sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

SEED_DEFAULT = 20260914
PHARMACIES = [
("Tambaram Demo Pharmacy 01","West Tambaram","Chennai","Chengalpattu"),
("Tambaram Demo Pharmacy 02","East Tambaram","Chennai","Chengalpattu"),
("Chromepet Demo Pharmacy 01","Chromepet","Chennai","Chengalpattu"),
("Pallavaram Demo Pharmacy 01","Pallavaram","Chennai","Chengalpattu"),
("Selaiyur Demo Pharmacy 01","Selaiyur","Chennai","Chengalpattu"),
("Perungalathur Demo Pharmacy 01","Perungalathur","Chennai","Chengalpattu"),
("Sholinganallur Demo Pharmacy 01","Sholinganallur","Chennai","Chengalpattu"),
("Velachery Demo Pharmacy 01","Velachery","Chennai","Chennai"),
("Adyar Demo Pharmacy 01","Adyar","Chennai","Chennai"),
("Guindy Demo Pharmacy 01","Guindy","Chennai","Chennai"),
("T Nagar Demo Pharmacy 01","T Nagar","Chennai","Chennai"),
("Anna Nagar Demo Pharmacy 01","Anna Nagar","Chennai","Chennai"),
("Porur Demo Pharmacy 01","Porur","Chennai","Chennai"),
("Avadi Demo Pharmacy 01","Avadi","Chennai","Tiruvallur"),
("Ambattur Demo Pharmacy 01","Ambattur","Chennai","Tiruvallur"),
("Coimbatore Demo Pharmacy 01","Gandhipuram","Coimbatore","Coimbatore"),
("Madurai Demo Pharmacy 01","Anna Nagar","Madurai","Madurai"),
("Tiruchirappalli Demo Pharmacy 01","Thillai Nagar","Tiruchirappalli","Tiruchirappalli"),
("Salem Demo Pharmacy 01","Fairlands","Salem","Salem"),
("Tirunelveli Demo Pharmacy 01","Palayamkottai","Tirunelveli","Tirunelveli"),
]
SCHEMA = Path(__file__).resolve().parents[1]/"sql"/"schema.sql"
ANCHOR = datetime(2026, 9, 14, 12, 0, 0, tzinfo=timezone.utc)

def read_catalogue(path):
    rows=[]
    with open(path, encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            def val(*keys):
                for k in keys:
                    v=(r.get(k) or "").strip()
                    if v: return v
                return None
            name=val("product_name", "Product Name")
            pid=val("product_identifier", "Product Identifier")
            if name and pid:
                rows.append({
                    "product_identifier":pid, "product_name":name,
                    "brand_identifier":val("brand_identifier", "Brand Identifier"),
                    "brand_name":val("brand_name", "Brand Name"),
                    "generic_identifier":val("generic_identifier", "Generic Identifier"),
                    "generic_name":val("generic_name", "Generic Name"),
                    "strength":val("strength", "Strength"),
                    "dosage_form":val("dosage_form", "Dose Form"),
                    "pack_size":val("pack_size", "Pack Size")})
    # A product identifier should have one catalogue snapshot; retain first occurrence.
    unique={}
    for r in rows: unique.setdefault(r["product_identifier"], r)
    return list(unique.values())

def main():
    ap=argparse.ArgumentParser(description="Generate repeatable synthetic inventory with shared products across pharmacies.")
    ap.add_argument("--catalogue-csv", required=True, help="CSV export from the CDCI catalogue_search view")
    ap.add_argument("--out", default="medaccess_cdci_inventory_v2.db", help="New output database; must not be an existing DB")
    ap.add_argument("--seed", type=int, default=SEED_DEFAULT)
    ap.add_argument("--product-pool-size", type=int, default=120, help="Number of distinct CDCI products to use")
    ap.add_argument("--min-pharmacies", type=int, default=5, help="Minimum pharmacies carrying each selected product")
    ap.add_argument("--max-pharmacies", type=int, default=10, help="Maximum pharmacies carrying each selected product")
    ap.add_argument("--history-days", type=int, default=7)
    a=ap.parse_args()
    if a.product_pool_size < 1: ap.error("--product-pool-size must be >= 1")
    if a.min_pharmacies < 1 or a.max_pharmacies < a.min_pharmacies or a.max_pharmacies > len(PHARMACIES):
        ap.error(f"Set 1 <= --min-pharmacies <= --max-pharmacies <= {len(PHARMACIES)}")
    catalogue=read_catalogue(a.catalogue_csv)
    if len(catalogue) < a.product_pool_size:
        ap.error(f"CSV has only {len(catalogue)} unique product identifiers; requested pool is {a.product_pool_size}")
    rng=random.Random(a.seed)
    rng.shuffle(catalogue)
    products=catalogue[:a.product_pool_size]
    out=Path(a.out).resolve(); out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists(): ap.error(f"Output already exists; choose a new filename to avoid overwriting: {out}")
    conn=sqlite3.connect(out); conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript(SCHEMA.read_text(encoding="utf-8")); cur=conn.cursor()
    for n,(name,loc,city,district) in enumerate(PHARMACIES,1):
        cur.execute("""INSERT INTO pharmacies(pharmacy_id,pharmacy_name,address_line,locality,city,district,state,
        postal_code,latitude,longitude,contact_phone,is_synthetic,created_at)
        VALUES(?,?,?,?,?,?,'Tamil Nadu',NULL,NULL,NULL,NULL,1,?)""",
        (f"DEMO-PH-{n:03d}",name,f"Fictional demo address, {loc}",loc,city,district,ANCHOR.isoformat()))
    # Assign each product to a random 5-10 distinct pharmacies; this makes comparison possible.
    pharmacy_products={i:[] for i in range(len(PHARMACIES))}
    for product in products:
        k=rng.randint(a.min_pharmacies, a.max_pharmacies)
        for pidx in sorted(rng.sample(range(len(PHARMACIES)), k)):
            pharmacy_products[pidx].append(product)
    total=0
    for pidx, meds in pharmacy_products.items():
        rng.shuffle(meds)
        for j,m in enumerate(meds,1):
            item=f"DEMO-INV-{pidx+1:03d}-{j:04d}"
            qty=rng.choice([0,0,2,4,6,9,12,18,24,36,48,60])
            status="out_of_stock" if qty==0 else ("low_stock" if qty<=5 else "in_stock")
            # Simulate price variation per pharmacy and product; not real retail pricing.
            base=rng.randrange(1200,15001,25)
            price=max(100, base + rng.randrange(-1500,1501,25))
            updated=(ANCHOR-timedelta(minutes=rng.randint(0,a.history_days*24*60))).isoformat()
            cur.execute("""INSERT INTO inventory_items(inventory_item_id,pharmacy_id,cdci_source,cdci_product_identifier,
            cdci_brand_identifier,cdci_generic_identifier,product_name_snapshot,brand_name_snapshot,generic_name_snapshot,
            strength_snapshot,dosage_form_snapshot,pack_size_snapshot,quantity_available,stock_status,price_inr_paise,
            currency,last_updated_at,data_origin,is_synthetic,catalogue_match_status,created_at)
            VALUES(?,?,'NRCeS Common Drug Codes for India',?,?,?,?,?,?,?,?,?,?,?,?, 'INR',?,'synthetic_seeded',1,'identifier_linked',?)""",
            (item,f"DEMO-PH-{pidx+1:03d}",m["product_identifier"],m["brand_identifier"],m["generic_identifier"],
             m["product_name"],m["brand_name"],m["generic_name"],m["strength"],m["dosage_form"],m["pack_size"],
             qty,status,price,updated,ANCHOR.isoformat()))
            cur.execute("INSERT INTO inventory_price_history VALUES(?,?,?,?, 'synthetic_seeded',1)",
             (f"DEMO-PRICE-{pidx+1:03d}-{j:04d}",item,price,updated))
            cur.execute("INSERT INTO inventory_stock_history VALUES(?,?,?,?, 'synthetic_seeded',1)",
             (f"DEMO-STOCK-{pidx+1:03d}-{j:04d}",item,qty,updated))
            total+=1
    cities=len({x[2] for x in PHARMACIES}); districts=len({x[3] for x in PHARMACIES})
    meta={"dataset_name":"MedAccess synthetic pharmacy inventory v2", "dataset_kind":"synthetic_demo_only",
      "seed":str(a.seed),"created_at_demo_anchor_utc":ANCHOR.isoformat(),"generator_version":"2.0",
      "pharmacy_count":str(len(PHARMACIES)),"city_count":str(cities),"district_count":str(districts),
      "product_pool_size":str(len(products)),"min_pharmacies_per_product":str(a.min_pharmacies),
      "max_pharmacies_per_product":str(a.max_pharmacies),"catalogue_csv_supplied":"yes",
      "warning":"All pharmacy names, addresses, prices, quantities and timestamps are synthetic demo data; not live or verified."}
    cur.executemany("INSERT INTO dataset_metadata VALUES (?,?)",meta.items())
    conn.commit()
    checks={
      "pharmacies":conn.execute("SELECT COUNT(*) FROM pharmacies").fetchone()[0],
      "cities":conn.execute("SELECT COUNT(DISTINCT city) FROM pharmacies").fetchone()[0],
      "districts":conn.execute("SELECT COUNT(DISTINCT district) FROM pharmacies").fetchone()[0],
      "inventory_rows":conn.execute("SELECT COUNT(*) FROM inventory_items").fetchone()[0],
      "unique_products":conn.execute("SELECT COUNT(DISTINCT cdci_product_identifier) FROM inventory_items").fetchone()[0],
      "min_pharmacies_per_product":conn.execute("SELECT MIN(n) FROM (SELECT COUNT(DISTINCT pharmacy_id) n FROM inventory_items GROUP BY cdci_product_identifier)").fetchone()[0],
      "max_pharmacies_per_product":conn.execute("SELECT MAX(n) FROM (SELECT COUNT(DISTINCT pharmacy_id) n FROM inventory_items GROUP BY cdci_product_identifier)").fetchone()[0],
      "identifier_linked_rows":conn.execute("SELECT COUNT(*) FROM inventory_items WHERE catalogue_match_status='identifier_linked'").fetchone()[0],
      "foreign_key_errors":len(conn.execute("PRAGMA foreign_key_check").fetchall()),
      "output":str(out),"seed":a.seed,"warning":meta["warning"]}
    conn.close()
    print(checks)
if __name__=="__main__": main()
