# MedAccess CDCI Integration — Stage 2 (V2 shared synthetic inventory)

This is a complete application folder based on the Stage 2 inventory-integrated package, updated to read the V2 shared-products synthetic inventory database.

## Included
- `frontend/`: React/Vite UI, including CDCI catalogue search and synthetic inventory panel.
- `backend/`: Express API and existing Stage 2 routes.
- `database/cdci_catalogue.db`: read-only CDCI catalogue database.
- `database/medaccess_cdci_inventory_v2.db`: V2 synthetic inventory, configured for the demo inventory API.
- `database/medaccess_cdci_inventory.db`: prior 700-row inventory database retained as a rollback/reference copy.
- `database/medaccess.db`: existing legacy application database, retained for current non-catalogue workflows.
- `scripts/generate_synthetic_inventory_v2.py` and `sql/schema.sql`: reproducibility assets.
- `README_DEMO_INVENTORY_INTEGRATION.md`, `README_CDCI_STAGE2_MAPPING.md`, and other notes.

## V2 validation already performed
- 20 fictional pharmacies
- 6 cities
- 8 districts
- 120 unique CDCI product identifiers
- 875 synthetic inventory rows
- Each selected product occurs at 5–10 demo pharmacies
- SQLite foreign-key check: 0 errors

## Run on Windows
Use Node.js/npm already installed on your computer.

### Backend
Open a terminal in `backend`:
```bat
npm install
npm start
```
Backend: `http://localhost:5000`

### Frontend
Open a second terminal in `frontend`:
```bat
npm install
npm run dev
```
Frontend: `http://localhost:5173`

Do not run two backend instances on port 5000 at the same time. Stop an older one with Ctrl+C first.

## Test the inventory API
Open a catalogue result in the app and copy its CDCI product identifier. Then visit:
`http://localhost:5000/api/demo-inventory?productIdentifier=PASTE_IDENTIFIER_HERE`

Expected response includes:
- `dataLabel: "DEMO DATA — NOT LIVE PHARMACY AVAILABILITY"`
- `isSynthetic: true`
- several pharmacy records for most selected V2 products

Products outside the seeded pool may correctly return `count: 0`.

## Important data and architecture limitations
- All pharmacy names, quantities, prices, stock statuses and timestamps are synthetic and must not be represented as live availability.
- `identifier_linked` means a row uses a CDCI product identifier. It does not establish product authenticity, clinical equivalence, or interchangeability.
- The inventory endpoint opens the V2 database read-only.
- The old `medaccess.db` is intentionally retained because other existing Stage 2 routes still depend on legacy records. This package does **not** claim that all old database dependencies have been retired.
- The prior inventory database is kept unchanged as a rollback/reference copy.
- This package is a full Stage 2 folder; it does not include `node_modules`. Run `npm install` separately in both `backend` and `frontend`.
