PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS pharmacies (
 pharmacy_id TEXT PRIMARY KEY, pharmacy_name TEXT NOT NULL, address_line TEXT NOT NULL,
 locality TEXT NOT NULL, city TEXT NOT NULL, district TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'Tamil Nadu', postal_code TEXT, latitude REAL, longitude REAL,
 contact_phone TEXT, is_synthetic INTEGER NOT NULL DEFAULT 1 CHECK(is_synthetic IN (0,1)),
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS inventory_items (
 inventory_item_id TEXT PRIMARY KEY, pharmacy_id TEXT NOT NULL REFERENCES pharmacies(pharmacy_id) ON DELETE CASCADE,
 cdci_source TEXT NOT NULL DEFAULT 'NRCeS Common Drug Codes for India',
 cdci_product_identifier TEXT, cdci_brand_identifier TEXT, cdci_generic_identifier TEXT,
 product_name_snapshot TEXT NOT NULL, brand_name_snapshot TEXT, generic_name_snapshot TEXT,
 strength_snapshot TEXT, dosage_form_snapshot TEXT, pack_size_snapshot TEXT,
 quantity_available INTEGER NOT NULL CHECK(quantity_available >= 0),
 stock_status TEXT NOT NULL CHECK(stock_status IN ('in_stock','low_stock','out_of_stock')),
 price_inr_paise INTEGER NOT NULL CHECK(price_inr_paise >= 0), currency TEXT NOT NULL DEFAULT 'INR',
 last_updated_at TEXT NOT NULL, data_origin TEXT NOT NULL DEFAULT 'synthetic_seeded',
 is_synthetic INTEGER NOT NULL DEFAULT 1 CHECK(is_synthetic IN (0,1)),
 catalogue_match_status TEXT NOT NULL DEFAULT 'unverified'
 CHECK(catalogue_match_status IN ('identifier_linked','unverified','unmatched')),
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_inventory_product ON inventory_items(cdci_product_identifier);
CREATE INDEX IF NOT EXISTS idx_inventory_brand ON inventory_items(cdci_brand_identifier);
CREATE INDEX IF NOT EXISTS idx_inventory_generic ON inventory_items(cdci_generic_identifier);
CREATE INDEX IF NOT EXISTS idx_inventory_pharmacy ON inventory_items(pharmacy_id);
CREATE INDEX IF NOT EXISTS idx_pharmacy_city ON pharmacies(city);
CREATE INDEX IF NOT EXISTS idx_inventory_name ON inventory_items(product_name_snapshot);
CREATE TABLE IF NOT EXISTS inventory_price_history (
 price_history_id TEXT PRIMARY KEY, inventory_item_id TEXT NOT NULL REFERENCES inventory_items(inventory_item_id) ON DELETE CASCADE,
 price_inr_paise INTEGER NOT NULL CHECK(price_inr_paise >= 0), recorded_at TEXT NOT NULL,
 data_origin TEXT NOT NULL DEFAULT 'synthetic_seeded', is_synthetic INTEGER NOT NULL DEFAULT 1 CHECK(is_synthetic IN (0,1))
);
CREATE TABLE IF NOT EXISTS inventory_stock_history (
 stock_history_id TEXT PRIMARY KEY, inventory_item_id TEXT NOT NULL REFERENCES inventory_items(inventory_item_id) ON DELETE CASCADE,
 quantity_available INTEGER NOT NULL CHECK(quantity_available >= 0), recorded_at TEXT NOT NULL,
 data_origin TEXT NOT NULL DEFAULT 'synthetic_seeded', is_synthetic INTEGER NOT NULL DEFAULT 1 CHECK(is_synthetic IN (0,1))
);
CREATE TABLE IF NOT EXISTS dataset_metadata (metadata_key TEXT PRIMARY KEY, metadata_value TEXT NOT NULL);
CREATE VIEW IF NOT EXISTS v_demo_inventory AS
SELECT i.inventory_item_id,p.pharmacy_id,p.pharmacy_name,p.locality,p.city,p.district,p.state,
 i.cdci_product_identifier,i.cdci_brand_identifier,i.cdci_generic_identifier,
 i.product_name_snapshot AS product_name,i.brand_name_snapshot AS brand_name,
 i.generic_name_snapshot AS generic_name,i.strength_snapshot AS strength,
 i.dosage_form_snapshot AS dosage_form,i.pack_size_snapshot AS pack_size,
 i.quantity_available,i.stock_status,ROUND(i.price_inr_paise/100.0,2) AS price_inr,
 i.last_updated_at,i.data_origin,i.is_synthetic,i.catalogue_match_status
FROM inventory_items i JOIN pharmacies p ON p.pharmacy_id=i.pharmacy_id;
