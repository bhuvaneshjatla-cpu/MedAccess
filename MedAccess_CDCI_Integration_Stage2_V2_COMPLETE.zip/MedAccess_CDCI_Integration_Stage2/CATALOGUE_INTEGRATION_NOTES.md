# MedAccess CDCI catalogue integration — initial safe step

## What changed
- Added `database/cdci_catalogue.db`, copied from the verified CDCI staging database.
- Added a read-only SQLite connection in `backend/src/database/catalogueDb.js`.
- Added `GET /api/catalogue?search=paracetamol&limit=25&offset=0` in `backend/src/routes/catalogueRoutes.js`.
- Registered `/api/catalogue` in the Express server.
- The existing `database/medaccess.db` and its `medicines`/inventory tables are not modified by these code changes.

## Test it
From `backend/` run:

```bash
npm start
```

Then open this URL in a browser:

`http://localhost:5000/api/catalogue?search=paracetamol`

Expected JSON includes `results` with brand/product/generic/supplier fields. Enter at least two characters. `limit` is capped at 100.

## Important status
This is the first integration step, not yet the complete frontend cutover. The existing UI and related routes use numeric `medicine_id` values from `medaccess.db` for pharmacy stock, prices, reports, reminders, and match-review records. CDCI identifiers are different identifiers. Switching the UI's existing `/api/medicines` route directly to CDCI rows would break those relationships. The safe next step is to update the medicine-search screen to use `/api/catalogue` for reference lookup while keeping inventory-bound workflows explicitly linked to existing local records until a deliberate mapping/migration is designed.

The CDCI data is reference terminology, not live stock/pricing. It does not prove clinical interchangeability. Preserve source attribution and review the source package's licensing terms before redistributing/deploying the database.
