# MedAccess CDCI Integration — Stage 2: Explicit Inventory Mapping

## What changed

- Added an additive `catalogue_inventory_mappings` table in the existing MedAccess SQLite database. It is created with `CREATE TABLE IF NOT EXISTS` when the catalogue routes load. Existing medicine, pharmacy, stock, price, reminder, report, and comparison rows are not deleted or rewritten.
- Added `GET /api/catalogue/:brandIdentifier/inventory`. It returns pharmacy availability and prices only when an explicit mapping exists. Otherwise it returns `mapped: false` and `No linked pharmacy data available.`
- Added `POST /api/catalogue/:brandIdentifier/mapping` to create/update a manually reviewed mapping to an existing `medicine_id`.
- Added `DELETE /api/catalogue/:brandIdentifier/mapping` to remove only the mapping row, never inventory records.
- The selected catalogue detail panel now displays linked inventory data, demo-data labels, and (for the demo Pharmacist or Administrator role) a mapping editor.
- No mappings are pre-created. Names/ingredients/strength are not automatically matched. A person must review the catalogue and legacy inventory record before linking.
- Set backend `better-sqlite3` dependency to `^12.8.0` because the previous Windows setup installed the 12.x line to avoid the Node 24 / native-build failure encountered with 13.0.3. Backend `package-lock.json` is intentionally omitted so `npm install` creates a compatible lockfile.

## Safe setup

1. Extract this ZIP to a **new folder**. Do not overwrite your previous working project.
2. Before the first run, make a separate copy of `database/medaccess.db` from this extracted folder as a rollback copy. If you have been using another working database in your existing project, back up that file separately and do not replace it with the ZIP's database.
3. In `backend`, run `npm install`, then `npm start`.
4. In `frontend`, run `npm install`, then `npm run dev`.
5. Test search using `paracetamol`.
6. Select a catalogue entry. Initially it should show `No linked pharmacy data available`, because the migration intentionally creates no guessed links.
7. Log in with the demo pharmacist (`pharmacist` / `pharmacist123`) or administrator (`admin` / `admin123`) and manually review a catalogue entry against an existing inventory item before saving a link.
8. Once mapped, availability and price records appear with an explicit demo-data warning.

## API examples

Search:

`GET http://localhost:5000/api/catalogue?search=paracetamol`

Look up mapping/inventory:

`GET http://localhost:5000/api/catalogue/1273171000189104/inventory`

Create mapping (demo API only; choose an actual medicine ID from `GET /api/medicines`):

`POST http://localhost:5000/api/catalogue/1273171000189104/mapping`

JSON body:

```json
{
  "medicine_id": 1,
  "mapped_by": "pharmacist",
  "mapping_note": "Reviewed product identity, strength, and dosage form manually"
}
```

Remove only the link:

`DELETE http://localhost:5000/api/catalogue/1273171000189104/mapping`

## Important limitations

- The project's current login is client-side demo login. The mapping API does **not** have server-side authentication/authorization yet. Do not expose this development server to the internet or treat the role-gated UI as a security boundary. Add real server-side authentication and role checks before deployment.
- The existing pharmacy availability and prices in this project are demo records, not live pharmacy data. The UI labels them accordingly.
- A manual catalogue mapping is an administrative data link, not a clinical interchangeability decision or a medicine substitution recommendation. Similar names alone are insufficient.
- CDCI catalogue data does not provide live stock or retail prices.
- This is an additive migration; it does not delete the old medicine rows. Retire or remove old rows only after all dependent workflows are migrated and tested separately.

## Rollback

1. Stop the backend.
2. Restore the backup copy of `database/medaccess.db` if you want to remove the additive mapping table and any mappings created during testing.
3. Alternatively, remove mapping rows through the DELETE endpoint; this leaves medicine, stock, price, and other records intact.
4. Keep the previous working project folder until all tests pass.
