# Stage 2 — Synthetic CDCI Inventory Integration

## What changed
- Added `backend/src/database/inventoryDb.js`, which opens `database/medaccess_cdci_inventory_v2.db` read-only.
- Added `backend/src/routes/demoInventoryRoutes.js` at `GET /api/demo-inventory?productIdentifier=<CDCI Product Identifier>`.
- Mounted the route in `backend/src/server.js`.
- Updated the catalogue detail panel in `frontend/src/App.jsx` to query the new endpoint by exact CDCI product identifier and label all returned records as synthetic demo data.
- The existing catalogue, legacy database, mapping routes, stock/prices, reports, and reminders are retained for safe incremental migration; this package does not yet retire every legacy database dependency.

## Install/run
1. Keep a backup of your existing Stage 2 folder.
2. Copy `database/medaccess_cdci_inventory_v2.db` into the Stage 2 `database` folder. Do not overwrite `medaccess.db` or `cdci_catalogue.db`.
3. In a terminal: `cd backend` then `npm install` if needed and `npm start`.
4. In another terminal: `cd frontend` then `npm install` if needed and `npm run dev`.
5. Test API in a browser: `http://localhost:5000/api/demo-inventory?productIdentifier=PUT_A_CDCI_PRODUCT_IDENTIFIER_HERE` (replace the placeholder with an identifier copied from a catalogue search result).
6. Search in the app and select a catalogue result. The panel should show synthetic inventory only when that exact product identifier is present in the V2 seeded dataset (120 products across 5–10 demo pharmacies each); otherwise it should clearly say no demo records exist for that catalogue product.

## Safety/limitations
- All pharmacies, stock quantities, prices and timestamps are synthetic. This is not a live pharmacy feed.
- `identifier_linked` means a row uses a CDCI product identifier; it is not clinical verification or a substitution recommendation.
- The inventory connection and endpoint are read-only. There is no write API for synthetic inventory.
- This is an additive integration stage. Existing non-catalogue workflows still use the legacy MedAccess database and should be migrated/tested separately before retiring it.
