const db = require("./db");

// Enable foreign-key enforcement.
db.pragma("foreign_keys = ON");

console.log("Initializing MedAccess database...");


// =========================================================
// HELPER: CHECK WHETHER A COLUMN EXISTS
// =========================================================

function columnExists(tableName, columnName) {
    const columns = db.prepare(`
        PRAGMA table_info(${tableName})
    `).all();

    return columns.some(
        (column) => column.name === columnName
    );
}


// =========================================================
// 1. CREATE TABLES
// =========================================================

db.exec(`
    CREATE TABLE IF NOT EXISTS roles (
        role_id INTEGER PRIMARY KEY AUTOINCREMENT,
        role_name TEXT NOT NULL UNIQUE
    );


    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        role_id INTEGER NOT NULL,

        FOREIGN KEY (role_id)
            REFERENCES roles(role_id)
    );


    CREATE TABLE IF NOT EXISTS medicines (
        medicine_id INTEGER PRIMARY KEY AUTOINCREMENT,
        medicine_name TEXT NOT NULL,
        active_ingredient TEXT NOT NULL,
        strength TEXT NOT NULL,
        dosage_form TEXT NOT NULL,
        pack_size TEXT NOT NULL,
        manufacturer TEXT
    );


    CREATE TABLE IF NOT EXISTS pharmacies (
        pharmacy_id INTEGER PRIMARY KEY AUTOINCREMENT,
        pharmacy_name TEXT NOT NULL,
        location TEXT NOT NULL
    );


    CREATE TABLE IF NOT EXISTS pharmacy_availability (
        availability_id INTEGER PRIMARY KEY AUTOINCREMENT,

        medicine_id INTEGER NOT NULL,

        pharmacy_id INTEGER NOT NULL,

        availability_status TEXT NOT NULL,

        stock_status TEXT,

        quantity INTEGER,

        last_updated TEXT,

        FOREIGN KEY (medicine_id)
            REFERENCES medicines(medicine_id),

        FOREIGN KEY (pharmacy_id)
            REFERENCES pharmacies(pharmacy_id)
    );


    CREATE TABLE IF NOT EXISTS prices (
        price_id INTEGER PRIMARY KEY AUTOINCREMENT,

        medicine_id INTEGER NOT NULL,

        pharmacy_id INTEGER NOT NULL,

        amount REAL NOT NULL,

        currency TEXT NOT NULL DEFAULT 'INR',

        last_updated TEXT,

        FOREIGN KEY (medicine_id)
            REFERENCES medicines(medicine_id),

        FOREIGN KEY (pharmacy_id)
            REFERENCES pharmacies(pharmacy_id)
    );


    CREATE TABLE IF NOT EXISTS potential_medicine_matches (
        match_id INTEGER PRIMARY KEY AUTOINCREMENT,

        medicine_id_1 INTEGER NOT NULL,

        medicine_id_2 INTEGER NOT NULL,

        match_status TEXT NOT NULL DEFAULT 'Pending',

        created_at TEXT DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (medicine_id_1)
            REFERENCES medicines(medicine_id),

        FOREIGN KEY (medicine_id_2)
            REFERENCES medicines(medicine_id)
    );


    CREATE TABLE IF NOT EXISTS medicine_comparisons (
        comparison_id INTEGER PRIMARY KEY AUTOINCREMENT,

        match_id INTEGER NOT NULL,

        comparison_status TEXT NOT NULL DEFAULT 'Pending',

        reviewed_by INTEGER,

        reviewed_at TEXT,

        FOREIGN KEY (match_id)
            REFERENCES potential_medicine_matches(match_id),

        FOREIGN KEY (reviewed_by)
            REFERENCES users(user_id)
    );


    /*
     * Kept for compatibility with the original prototype.
     *
     * The current pharmacist workflow stores comments directly
     * in medicine_comparison_status_history.
     */
    CREATE TABLE IF NOT EXISTS verification_comments (
        comment_id INTEGER PRIMARY KEY AUTOINCREMENT,

        comparison_id INTEGER NOT NULL,

        pharmacist_id INTEGER NOT NULL,

        comment_text TEXT NOT NULL,

        created_at TEXT DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (comparison_id)
            REFERENCES medicine_comparisons(comparison_id),

        FOREIGN KEY (pharmacist_id)
            REFERENCES users(user_id)
    );


    /*
     * Stores every Verify / Reject action.
     */
    CREATE TABLE IF NOT EXISTS medicine_comparison_status_history (
        history_id INTEGER PRIMARY KEY AUTOINCREMENT,

        comparison_id INTEGER NOT NULL,

        previous_status TEXT,

        new_status TEXT NOT NULL,

        pharmacist_id INTEGER NOT NULL,

        comment_text TEXT,

        created_at TEXT DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (comparison_id)
            REFERENCES medicine_comparisons(comparison_id),

        FOREIGN KEY (pharmacist_id)
            REFERENCES users(user_id)
    );
`);

console.log("Tables checked.");


// =========================================================
// 2. DATABASE SCHEMA MIGRATION
// =========================================================
//
// The existing database was created using an older version
// of the prototype.
//
// Older availability data may contain:
//     availability_status
//     available_quantity
//
// Newer application code uses:
//     stock_status
//     quantity
//     last_updated
//
// We keep the old columns and add the new ones.
//

if (
    !columnExists(
        "pharmacy_availability",
        "stock_status"
    )
) {

    db.exec(`
        ALTER TABLE pharmacy_availability
        ADD COLUMN stock_status TEXT
    `);

    console.log(
        "Added missing pharmacy_availability.stock_status column."
    );
}


if (
    !columnExists(
        "pharmacy_availability",
        "quantity"
    )
) {

    db.exec(`
        ALTER TABLE pharmacy_availability
        ADD COLUMN quantity INTEGER
    `);

    console.log(
        "Added missing pharmacy_availability.quantity column."
    );
}


if (
    !columnExists(
        "pharmacy_availability",
        "last_updated"
    )
) {

    db.exec(`
        ALTER TABLE pharmacy_availability
        ADD COLUMN last_updated TEXT
    `);

    console.log(
        "Added missing pharmacy_availability.last_updated column."
    );
}


// ---------------------------------------------------------
// Migrate old available_quantity → quantity
// ---------------------------------------------------------

if (
    columnExists(
        "pharmacy_availability",
        "available_quantity"
    ) &&
    columnExists(
        "pharmacy_availability",
        "quantity"
    )
) {

    db.exec(`
        UPDATE pharmacy_availability
        SET quantity = available_quantity
        WHERE quantity IS NULL
    `);

    console.log(
        "Migrated available_quantity values to quantity."
    );
}


// ---------------------------------------------------------
// Populate stock_status from quantity
// ---------------------------------------------------------

if (
    columnExists(
        "pharmacy_availability",
        "stock_status"
    ) &&
    columnExists(
        "pharmacy_availability",
        "quantity"
    )
) {

    db.exec(`
    UPDATE pharmacy_availability

    SET stock_status =
        CASE
            WHEN quantity IS NOT NULL AND quantity <= 0
                THEN 'Out of Stock'

            WHEN quantity IS NOT NULL AND quantity <= 10
                THEN 'Low Stock'

            WHEN quantity IS NOT NULL
                THEN 'In Stock'

            WHEN availability_status = 'Unavailable'
                THEN 'Out of Stock'

            WHEN availability_status = 'Available'
                THEN 'In Stock'

            ELSE 'Out of Stock'
        END

    WHERE stock_status IS NULL
       OR stock_status = ''
`);

db.exec(`
    UPDATE pharmacy_availability

    SET quantity =
        CASE
            WHEN availability_status = 'Unavailable'
                THEN 0

            WHEN availability_status = 'Available'
                THEN 20

            ELSE 0
        END

    WHERE quantity IS NULL
`);

db.exec(`
    UPDATE pharmacy_availability

    SET stock_status =
        CASE
            WHEN quantity <= 0
                THEN 'Out of Stock'

            WHEN quantity <= 10
                THEN 'Low Stock'

            ELSE 'In Stock'
        END

    WHERE stock_status IS NULL
       OR stock_status = ''
`);

    console.log(
        "Updated missing stock statuses from quantity."
    );
}


// ---------------------------------------------------------
// Keep legacy availability_status populated
// ---------------------------------------------------------

if (
    columnExists(
        "pharmacy_availability",
        "availability_status"
    ) &&
    columnExists(
        "pharmacy_availability",
        "quantity"
    )
) {

    db.exec(`
        UPDATE pharmacy_availability

        SET availability_status =
            CASE

                WHEN quantity IS NULL
                    THEN 'Unavailable'

                WHEN quantity <= 0
                    THEN 'Unavailable'

                ELSE 'Available'

            END

        WHERE availability_status IS NULL
           OR availability_status = ''
    `);

    console.log(
        "Updated existing availability_status values."
    );
}


console.log("Database schema migration checked.");


// =========================================================
// 3. INSERT ROLES WITHOUT DUPLICATES
// =========================================================

const insertRole = db.prepare(`
    INSERT OR IGNORE INTO roles (
        role_name
    )
    VALUES (?)
`);


const roles = [
    "Patient",
    "Caregiver",
    "Pharmacist",
    "Pharmacy Staff",
    "Administrator"
];


for (const role of roles) {
    insertRole.run(role);
}


console.log("Roles checked.");


// =========================================================
// 4. INSERT DEMO USERS WITHOUT DUPLICATES
// =========================================================

const getRoleId = db.prepare(`
    SELECT role_id
    FROM roles
    WHERE role_name = ?
`);


const insertUser = db.prepare(`
    INSERT OR IGNORE INTO users (
        username,
        password,
        role_id
    )
    VALUES (?, ?, ?)
`);


const patientRole = getRoleId.get("Patient");

const pharmacistRole = getRoleId.get("Pharmacist");

const adminRole = getRoleId.get("Administrator");


if (patientRole) {

    insertUser.run(
        "patient",
        "patient123",
        patientRole.role_id
    );
}


if (pharmacistRole) {

    insertUser.run(
        "pharmacist",
        "pharmacist123",
        pharmacistRole.role_id
    );
}


if (adminRole) {

    insertUser.run(
        "admin",
        "admin123",
        adminRole.role_id
    );
}


console.log("Demo users checked.");


// =========================================================
// 5. CLEAN DUPLICATE USERS
// =========================================================

const duplicateUsers = db.prepare(`
    SELECT
        username,
        MIN(user_id) AS keep_id

    FROM users

    GROUP BY username

    HAVING COUNT(*) > 1
`).all();


for (const user of duplicateUsers) {

    const duplicates = db.prepare(`
        SELECT user_id

        FROM users

        WHERE username = ?

          AND user_id != ?
    `).all(
        user.username,
        user.keep_id
    );


    for (const duplicate of duplicates) {

        db.prepare(`
            UPDATE medicine_comparisons

            SET reviewed_by = ?

            WHERE reviewed_by = ?
        `).run(
            user.keep_id,
            duplicate.user_id
        );


        db.prepare(`
            UPDATE medicine_comparison_status_history

            SET pharmacist_id = ?

            WHERE pharmacist_id = ?
        `).run(
            user.keep_id,
            duplicate.user_id
        );


        db.prepare(`
            UPDATE verification_comments

            SET pharmacist_id = ?

            WHERE pharmacist_id = ?
        `).run(
            user.keep_id,
            duplicate.user_id
        );


        db.prepare(`
            DELETE FROM users

            WHERE user_id = ?
        `).run(
            duplicate.user_id
        );
    }
}


// =========================================================
// 6. CLEAN DUPLICATE MEDICINES
// =========================================================

const duplicateMedicines = db.prepare(`
    SELECT
        medicine_name,
        active_ingredient,
        strength,
        dosage_form,
        pack_size,
        COALESCE(manufacturer, '') AS manufacturer,
        MIN(medicine_id) AS keep_id

    FROM medicines

    GROUP BY
        medicine_name,
        active_ingredient,
        strength,
        dosage_form,
        pack_size,
        COALESCE(manufacturer, '')

    HAVING COUNT(*) > 1
`).all();


for (const medicine of duplicateMedicines) {

    const duplicates = db.prepare(`
        SELECT medicine_id

        FROM medicines

        WHERE medicine_name = ?
          AND active_ingredient = ?
          AND strength = ?
          AND dosage_form = ?
          AND pack_size = ?
          AND COALESCE(manufacturer, '') = ?
          AND medicine_id != ?
    `).all(
        medicine.medicine_name,
        medicine.active_ingredient,
        medicine.strength,
        medicine.dosage_form,
        medicine.pack_size,
        medicine.manufacturer,
        medicine.keep_id
    );


    for (const duplicate of duplicates) {

        db.prepare(`
            UPDATE pharmacy_availability

            SET medicine_id = ?

            WHERE medicine_id = ?
        `).run(
            medicine.keep_id,
            duplicate.medicine_id
        );


        db.prepare(`
            UPDATE prices

            SET medicine_id = ?

            WHERE medicine_id = ?
        `).run(
            medicine.keep_id,
            duplicate.medicine_id
        );


        db.prepare(`
            UPDATE potential_medicine_matches

            SET medicine_id_1 = ?

            WHERE medicine_id_1 = ?
        `).run(
            medicine.keep_id,
            duplicate.medicine_id
        );


        db.prepare(`
            UPDATE potential_medicine_matches

            SET medicine_id_2 = ?

            WHERE medicine_id_2 = ?
        `).run(
            medicine.keep_id,
            duplicate.medicine_id
        );


        db.prepare(`
            DELETE FROM medicines

            WHERE medicine_id = ?
        `).run(
            duplicate.medicine_id
        );
    }
}


console.log("Duplicate medicines cleaned.");


// =========================================================
// 7. CLEAN DUPLICATE PHARMACIES
// =========================================================

const duplicatePharmacies = db.prepare(`
    SELECT
        pharmacy_name,
        location,
        MIN(pharmacy_id) AS keep_id

    FROM pharmacies

    GROUP BY
        pharmacy_name,
        location

    HAVING COUNT(*) > 1
`).all();


for (const pharmacy of duplicatePharmacies) {

    const duplicates = db.prepare(`
        SELECT pharmacy_id

        FROM pharmacies

        WHERE pharmacy_name = ?
          AND location = ?
          AND pharmacy_id != ?
    `).all(
        pharmacy.pharmacy_name,
        pharmacy.location,
        pharmacy.keep_id
    );


    for (const duplicate of duplicates) {

        db.prepare(`
            UPDATE pharmacy_availability

            SET pharmacy_id = ?

            WHERE pharmacy_id = ?
        `).run(
            pharmacy.keep_id,
            duplicate.pharmacy_id
        );


        db.prepare(`
            UPDATE prices

            SET pharmacy_id = ?

            WHERE pharmacy_id = ?
        `).run(
            pharmacy.keep_id,
            duplicate.pharmacy_id
        );


        db.prepare(`
            DELETE FROM pharmacies

            WHERE pharmacy_id = ?
        `).run(
            duplicate.pharmacy_id
        );
    }
}


console.log("Duplicate pharmacies cleaned.");


// =========================================================
// 8. CLEAN DUPLICATE AVAILABILITY RECORDS
// =========================================================

const duplicateAvailability = db.prepare(`
    SELECT
        medicine_id,
        pharmacy_id,
        MIN(availability_id) AS keep_id

    FROM pharmacy_availability

    GROUP BY
        medicine_id,
        pharmacy_id

    HAVING COUNT(*) > 1
`).all();


for (const availability of duplicateAvailability) {

    db.prepare(`
        DELETE FROM pharmacy_availability

        WHERE medicine_id = ?
          AND pharmacy_id = ?
          AND availability_id != ?
    `).run(
        availability.medicine_id,
        availability.pharmacy_id,
        availability.keep_id
    );
}


console.log(
    "Duplicate availability records cleaned."
);


// =========================================================
// 9. CLEAN DUPLICATE PRICE RECORDS
// =========================================================

const duplicatePrices = db.prepare(`
    SELECT
        medicine_id,
        pharmacy_id,
        MIN(price_id) AS keep_id

    FROM prices

    GROUP BY
        medicine_id,
        pharmacy_id

    HAVING COUNT(*) > 1
`).all();


for (const price of duplicatePrices) {

    db.prepare(`
        DELETE FROM prices

        WHERE medicine_id = ?
          AND pharmacy_id = ?
          AND price_id != ?
    `).run(
        price.medicine_id,
        price.pharmacy_id,
        price.keep_id
    );
}


console.log(
    "Duplicate price records cleaned."
);


// =========================================================
// 10. INSERT DEMO MEDICINES
// =========================================================

const insertMedicine = db.prepare(`
    INSERT INTO medicines (
        medicine_name,
        active_ingredient,
        strength,
        dosage_form,
        pack_size,
        manufacturer
    )

    SELECT ?, ?, ?, ?, ?, ?

    WHERE NOT EXISTS (

        SELECT 1

        FROM medicines

        WHERE medicine_name = ?
          AND active_ingredient = ?
          AND strength = ?
          AND dosage_form = ?
          AND pack_size = ?
          AND COALESCE(manufacturer, '') =
              COALESCE(?, '')
    )
`);


const demoMedicines = [

    [
        "Paracetamol",
        "Paracetamol",
        "500 mg",
        "Tablet",
        "10 tablets",
        "Generic Manufacturer"
    ],

    [
        "Cetirizine",
        "Cetirizine",
        "10 mg",
        "Tablet",
        "10 tablets",
        "Generic Manufacturer"
    ],

    [
        "Amoxicillin",
        "Amoxicillin",
        "500 mg",
        "Capsule",
        "10 capsules",
        "Generic Manufacturer"
    ]

];


for (const medicine of demoMedicines) {

    insertMedicine.run(
        ...medicine,
        ...medicine
    );
}


console.log("Demo medicines checked.");


// =========================================================
// 11. INSERT DEMO PHARMACIES
// =========================================================

const insertPharmacy = db.prepare(`
    INSERT INTO pharmacies (
        pharmacy_name,
        location
    )

    SELECT ?, ?

    WHERE NOT EXISTS (

        SELECT 1

        FROM pharmacies

        WHERE pharmacy_name = ?
          AND location = ?
    )
`);


const demoPharmacies = [

    [
        "MedAccess Pharmacy A",
        "Chennai"
    ],

    [
        "MedAccess Pharmacy B",
        "Chennai"
    ],

    [
        "MedAccess Pharmacy C",
        "Chennai"
    ]

];


for (const pharmacy of demoPharmacies) {

    insertPharmacy.run(
        ...pharmacy,
        ...pharmacy
    );
}


console.log("Demo pharmacies checked.");


// =========================================================
// 12. GET MEDICINE IDS
// =========================================================

const getMedicineId = db.prepare(`
    SELECT medicine_id

    FROM medicines

    WHERE medicine_name = ?
      AND active_ingredient = ?
      AND strength = ?
      AND dosage_form = ?
      AND pack_size = ?

    ORDER BY medicine_id ASC

    LIMIT 1
`);


const paracetamol = getMedicineId.get(
    "Paracetamol",
    "Paracetamol",
    "500 mg",
    "Tablet",
    "10 tablets"
);


const cetirizine = getMedicineId.get(
    "Cetirizine",
    "Cetirizine",
    "10 mg",
    "Tablet",
    "10 tablets"
);


const amoxicillin = getMedicineId.get(
    "Amoxicillin",
    "Amoxicillin",
    "500 mg",
    "Capsule",
    "10 capsules"
);


// =========================================================
// 13. GET PHARMACY IDS
// =========================================================

const getPharmacyId = db.prepare(`
    SELECT pharmacy_id

    FROM pharmacies

    WHERE pharmacy_name = ?
      AND location = ?

    ORDER BY pharmacy_id ASC

    LIMIT 1
`);


const pharmacyA = getPharmacyId.get(
    "MedAccess Pharmacy A",
    "Chennai"
);


const pharmacyB = getPharmacyId.get(
    "MedAccess Pharmacy B",
    "Chennai"
);


const pharmacyC = getPharmacyId.get(
    "MedAccess Pharmacy C",
    "Chennai"
);


// =========================================================
// 14. INSERT DEMO AVAILABILITY
// =========================================================
//
// IMPORTANT:
//
// The existing database has a required
// `availability_status` column.
//
// Therefore we populate BOTH:
//
// availability_status
// stock_status
//
// This keeps the old database schema compatible with
// the current application.
//

const insertAvailability = db.prepare(`
    INSERT INTO pharmacy_availability (
        medicine_id,
        pharmacy_id,
        availability_status,
        stock_status,
        quantity,
        last_updated
    )

    SELECT ?, ?, ?, ?, ?, ?

    WHERE NOT EXISTS (

        SELECT 1

        FROM pharmacy_availability

        WHERE medicine_id = ?
          AND pharmacy_id = ?
    )
`);


const availabilityData = [

    [
        paracetamol,
        pharmacyA,
        "In Stock",
        50,
        "2026-09-14 10:00:00"
    ],

    [
        paracetamol,
        pharmacyB,
        "In Stock",
        25,
        "2026-09-14 10:15:00"
    ],

    [
        paracetamol,
        pharmacyC,
        "Low Stock",
        5,
        "2026-09-14 10:30:00"
    ],

    [
        cetirizine,
        pharmacyA,
        "In Stock",
        30,
        "2026-09-14 11:00:00"
    ],

    [
        cetirizine,
        pharmacyB,
        "Low Stock",
        8,
        "2026-09-14 11:15:00"
    ],

    [
        cetirizine,
        pharmacyC,
        "Out of Stock",
        0,
        "2026-09-14 11:30:00"
    ],

    [
        amoxicillin,
        pharmacyA,
        "In Stock",
        20,
        "2026-09-14 12:00:00"
    ],

    [
        amoxicillin,
        pharmacyB,
        "In Stock",
        15,
        "2026-09-14 12:15:00"
    ],

    [
        amoxicillin,
        pharmacyC,
        "Low Stock",
        4,
        "2026-09-14 12:30:00"
    ]

];


for (const item of availabilityData) {

    const [
        medicine,
        pharmacy,
        stockStatus,
        quantity,
        lastUpdated
    ] = item;


    if (!medicine || !pharmacy) {
        continue;
    }


    const availabilityStatus =
        quantity > 0
            ? "Available"
            : "Unavailable";


    insertAvailability.run(

        medicine.medicine_id,

        pharmacy.pharmacy_id,

        availabilityStatus,

        stockStatus,

        quantity,

        lastUpdated,

        medicine.medicine_id,

        pharmacy.pharmacy_id
    );
}


console.log("Demo availability checked.");


// =========================================================
// 15. INSERT DEMO PRICES
// =========================================================

const insertPrice = db.prepare(`
    INSERT INTO prices (
        medicine_id,
        pharmacy_id,
        amount,
        currency,
        last_updated
    )

    SELECT ?, ?, ?, ?, ?

    WHERE NOT EXISTS (

        SELECT 1

        FROM prices

        WHERE medicine_id = ?
          AND pharmacy_id = ?
    )
`);


const priceData = [

    [
        paracetamol,
        pharmacyA,
        25.00,
        "INR",
        "2026-09-14 10:00:00"
    ],

    [
        paracetamol,
        pharmacyB,
        28.00,
        "INR",
        "2026-09-14 10:15:00"
    ],

    [
        paracetamol,
        pharmacyC,
        22.00,
        "INR",
        "2026-09-14 10:30:00"
    ],

    [
        cetirizine,
        pharmacyA,
        35.00,
        "INR",
        "2026-09-14 11:00:00"
    ],

    [
        cetirizine,
        pharmacyB,
        32.00,
        "INR",
        "2026-09-14 11:15:00"
    ],

    [
        cetirizine,
        pharmacyC,
        38.00,
        "INR",
        "2026-09-14 11:30:00"
    ],

    [
        amoxicillin,
        pharmacyA,
        75.00,
        "INR",
        "2026-09-14 12:00:00"
    ],

    [
        amoxicillin,
        pharmacyB,
        80.00,
        "INR",
        "2026-09-14 12:15:00"
    ],

    [
        amoxicillin,
        pharmacyC,
        72.00,
        "INR",
        "2026-09-14 12:30:00"
    ]

];


for (const item of priceData) {

    const [
        medicine,
        pharmacy,
        amount,
        currency,
        lastUpdated
    ] = item;


    if (!medicine || !pharmacy) {
        continue;
    }


    insertPrice.run(

        medicine.medicine_id,

        pharmacy.pharmacy_id,

        amount,

        currency,

        lastUpdated,

        medicine.medicine_id,

        pharmacy.pharmacy_id
    );
}


console.log("Demo prices checked.");


// =========================================================
// 16. CLEAN DUPLICATE MEDICINE MATCHES
// =========================================================

const duplicateMatches = db.prepare(`
    SELECT
        medicine_id_1,
        medicine_id_2,
        MIN(match_id) AS keep_id

    FROM potential_medicine_matches

    GROUP BY
        medicine_id_1,
        medicine_id_2

    HAVING COUNT(*) > 1
`).all();


for (const match of duplicateMatches) {

    const duplicates = db.prepare(`
        SELECT match_id

        FROM potential_medicine_matches

        WHERE medicine_id_1 = ?
          AND medicine_id_2 = ?
          AND match_id != ?
    `).all(
        match.medicine_id_1,
        match.medicine_id_2,
        match.keep_id
    );


    for (const duplicate of duplicates) {

        db.prepare(`
            UPDATE medicine_comparisons

            SET match_id = ?

            WHERE match_id = ?
        `).run(
            match.keep_id,
            duplicate.match_id
        );


        db.prepare(`
            DELETE FROM potential_medicine_matches

            WHERE match_id = ?
        `).run(
            duplicate.match_id
        );
    }
}


console.log(
    "Duplicate medicine matches cleaned."
);


// =========================================================
// 17. CLEAN DUPLICATE COMPARISONS
// =========================================================

const duplicateComparisons = db.prepare(`
    SELECT
        match_id,
        MIN(comparison_id) AS keep_id

    FROM medicine_comparisons

    GROUP BY match_id

    HAVING COUNT(*) > 1
`).all();


for (const comparison of duplicateComparisons) {

    const duplicates = db.prepare(`
        SELECT comparison_id

        FROM medicine_comparisons

        WHERE match_id = ?

          AND comparison_id != ?
    `).all(
        comparison.match_id,
        comparison.keep_id
    );


    for (const duplicate of duplicates) {

        db.prepare(`
            UPDATE medicine_comparison_status_history

            SET comparison_id = ?

            WHERE comparison_id = ?
        `).run(
            comparison.keep_id,
            duplicate.comparison_id
        );


        db.prepare(`
            UPDATE verification_comments

            SET comparison_id = ?

            WHERE comparison_id = ?
        `).run(
            comparison.keep_id,
            duplicate.comparison_id
        );


        db.prepare(`
            DELETE FROM medicine_comparisons

            WHERE comparison_id = ?
        `).run(
            duplicate.comparison_id
        );
    }
}


console.log(
    "Duplicate comparisons cleaned."
);


// =========================================================
// 18. INSERT DEMO MEDICINE MATCHES
// =========================================================
//
// These are demonstration review cases only.
// They do NOT represent a claim that the medicines are
// interchangeable.
//

const insertMatch = db.prepare(`
    INSERT INTO potential_medicine_matches (
        medicine_id_1,
        medicine_id_2,
        match_status
    )

    SELECT ?, ?, ?

    WHERE NOT EXISTS (

        SELECT 1

        FROM potential_medicine_matches

        WHERE medicine_id_1 = ?
          AND medicine_id_2 = ?
    )
`);


if (paracetamol && cetirizine) {

    insertMatch.run(

        paracetamol.medicine_id,

        cetirizine.medicine_id,

        "Pending",

        paracetamol.medicine_id,

        cetirizine.medicine_id
    );
}


if (cetirizine && amoxicillin) {

    insertMatch.run(

        cetirizine.medicine_id,

        amoxicillin.medicine_id,

        "Pending",

        cetirizine.medicine_id,

        amoxicillin.medicine_id
    );
}


console.log(
    "Demo medicine matches checked."
);


// =========================================================
// 19. INSERT COMPARISON RECORDS
// =========================================================

const matches = db.prepare(`
    SELECT
        match_id,
        match_status

    FROM potential_medicine_matches

    ORDER BY match_id
`).all();


const insertComparison = db.prepare(`
    INSERT INTO medicine_comparisons (
        match_id,
        comparison_status
    )

    SELECT ?, ?

    WHERE NOT EXISTS (

        SELECT 1

        FROM medicine_comparisons

        WHERE match_id = ?
    )
`);


for (const match of matches) {

    insertComparison.run(

        match.match_id,

        match.match_status || "Pending",

        match.match_id
    );
}


console.log(
    "Comparison records checked."
);


// =========================================================
// 20. SYNCHRONIZE MATCH STATUS
// =========================================================
//
// Keep the potential match status synchronized with the
// current comparison status.
//

db.exec(`
    UPDATE potential_medicine_matches

    SET match_status = (

        SELECT comparison_status

        FROM medicine_comparisons

        WHERE medicine_comparisons.match_id =
              potential_medicine_matches.match_id

        LIMIT 1
    )

    WHERE EXISTS (

        SELECT 1

        FROM medicine_comparisons

        WHERE medicine_comparisons.match_id =
              potential_medicine_matches.match_id
    );
`);


console.log(
    "Match and comparison statuses synchronized."
);


// =========================================================
// 21. CREATE UNIQUE INDEXES
// =========================================================
//
// These prevent future duplicate seed data.
//

db.exec(`
    CREATE UNIQUE INDEX IF NOT EXISTS
        idx_medicines_unique_details

    ON medicines (
        medicine_name,
        active_ingredient,
        strength,
        dosage_form,
        pack_size,
        COALESCE(manufacturer, '')
    );


    CREATE UNIQUE INDEX IF NOT EXISTS
        idx_pharmacies_unique_details

    ON pharmacies (
        pharmacy_name,
        location
    );


    CREATE UNIQUE INDEX IF NOT EXISTS
        idx_availability_medicine_pharmacy

    ON pharmacy_availability (
        medicine_id,
        pharmacy_id
    );


    CREATE UNIQUE INDEX IF NOT EXISTS
        idx_prices_medicine_pharmacy

    ON prices (
        medicine_id,
        pharmacy_id
    );


    CREATE UNIQUE INDEX IF NOT EXISTS
        idx_medicine_match_pair

    ON potential_medicine_matches (
        medicine_id_1,
        medicine_id_2
    );


    CREATE UNIQUE INDEX IF NOT EXISTS
        idx_comparison_match

    ON medicine_comparisons (
        match_id
    );
`);


console.log("Indexes checked.");


// =========================================================
// COMPLETE
// =========================================================

console.log("");

console.log("==============================================");

console.log(
    "MedAccess database initialization complete."
);

console.log("==============================================");

console.log("");