const Database = require("better-sqlite3");
const path = require("path");

// Synthetic demo inventory is stored separately from the legacy MedAccess DB.
// Open read-only and enforce query_only to prevent API writes.
const inventoryPath = path.join(__dirname, "../../../database/medaccess_cdci_inventory_v2.db");
const inventoryDb = new Database(inventoryPath, { readonly: true, fileMustExist: true });
inventoryDb.pragma("query_only = ON");

module.exports = inventoryDb;
