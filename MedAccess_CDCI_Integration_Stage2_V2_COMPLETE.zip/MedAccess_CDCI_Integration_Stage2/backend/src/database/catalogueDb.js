const Database = require("better-sqlite3");
const path = require("path");

// The CDCI terminology catalogue is kept separate from pharmacy inventory.
// Open read-only so normal application requests cannot alter the source data.
const cataloguePath = path.join(__dirname, "../../../database/cdci_catalogue.db");
const catalogueDb = new Database(cataloguePath, { readonly: true, fileMustExist: true });
catalogueDb.pragma("query_only = ON");

module.exports = catalogueDb;
