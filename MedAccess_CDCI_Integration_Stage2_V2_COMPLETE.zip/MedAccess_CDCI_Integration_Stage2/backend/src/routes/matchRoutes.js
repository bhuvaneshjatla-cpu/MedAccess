const express = require("express");

const router = express.Router();

const db = require("../database/db");

// Get medicine matches for pharmacist review
router.get("/", (req, res) => {
    try {
        const matches = db.prepare(`
            SELECT
                pm.match_id,
                pm.match_status,
                pm.created_at,

                mc.comparison_id,
                mc.comparison_status,
                mc.reviewed_by,
                mc.reviewed_at,

                m1.medicine_id AS medicine_id_1,
                m1.medicine_name AS medicine_name_1,
                m1.active_ingredient AS active_ingredient_1,
                m1.strength AS strength_1,
                m1.dosage_form AS dosage_form_1,
                m1.pack_size AS pack_size_1,

                m2.medicine_id AS medicine_id_2,
                m2.medicine_name AS medicine_name_2,
                m2.active_ingredient AS active_ingredient_2,
                m2.strength AS strength_2,
                m2.dosage_form AS dosage_form_2,
                m2.pack_size AS pack_size_2

            FROM potential_medicine_matches pm

            JOIN medicine_comparisons mc
                ON pm.match_id = mc.match_id

            JOIN medicines m1
                ON pm.medicine_id_1 = m1.medicine_id

            JOIN medicines m2
                ON pm.medicine_id_2 = m2.medicine_id

            ORDER BY pm.created_at DESC
        `).all();

        res.json(matches);

    } catch (error) {
        console.error("Error fetching medicine matches:", error);

        res.status(500).json({
            error: "Unable to fetch medicine matches."
        });
    }
});

module.exports = router;