const express = require("express");
const router = express.Router();

const db = require("../database/db");


// ---------------------------------------------------------
// GET: View comparison details
// ---------------------------------------------------------
router.get("/:comparisonId", (req, res) => {
    const comparisonId = Number(req.params.comparisonId);

    try {
        const comparison = db.prepare(`
            SELECT
                mc.comparison_id,
                mc.comparison_status,
                mc.reviewed_by,
                mc.reviewed_at,

                pm.match_id,
                pm.match_status,
                pm.created_at,

                m1.medicine_id AS medicine_id_1,
                m1.medicine_name AS medicine_name_1,
                m1.active_ingredient AS active_ingredient_1,
                m1.strength AS strength_1,
                m1.dosage_form AS dosage_form_1,
                m1.pack_size AS pack_size_1,

                m2.medicine_id AS medicine_id_2,
                m2.medicine_name AS medicine_name_2,
                m2.active_ingredient AS active_ingredient_2,
                m2.strength AS strength_2,
                m2.dosage_form AS dosage_form_2,
                m2.pack_size AS pack_size_2

            FROM medicine_comparisons mc

            JOIN potential_medicine_matches pm
                ON mc.match_id = pm.match_id

            JOIN medicines m1
                ON pm.medicine_id_1 = m1.medicine_id

            JOIN medicines m2
                ON pm.medicine_id_2 = m2.medicine_id

            WHERE mc.comparison_id = ?
        `).get(comparisonId);


        if (!comparison) {
            return res.status(404).json({
                error: "Comparison not found."
            });
        }


        // Status history
        const statusHistory = db.prepare(`
            SELECT
                h.history_id,
                h.previous_status,
                h.new_status,
                h.comment_text,
                h.created_at,

                u.user_id AS pharmacist_id,
                u.username AS pharmacist_username

            FROM medicine_comparison_status_history h

            JOIN users u
                ON h.pharmacist_id = u.user_id

            WHERE h.comparison_id = ?

            ORDER BY h.created_at DESC, h.history_id DESC
        `).all(comparisonId);


        res.json({
            ...comparison,
            statusHistory
        });

    } catch (error) {
        console.error("Error fetching comparison:", error);

        res.status(500).json({
            error: "Unable to fetch comparison."
        });
    }
});


// ---------------------------------------------------------
// POST: Verify comparison
// ---------------------------------------------------------
router.post("/:comparisonId/verify", (req, res) => {
    const comparisonId = Number(req.params.comparisonId);

    const comment =
        typeof req.body.comment === "string"
            ? req.body.comment.trim()
            : "";


    if (!comment) {
        return res.status(400).json({
            error: "A verification comment is required."
        });
    }


    try {
        const comparison = db.prepare(`
            SELECT
                comparison_id,
                comparison_status,
                match_id
            FROM medicine_comparisons
            WHERE comparison_id = ?
        `).get(comparisonId);


        if (!comparison) {
            return res.status(404).json({
                error: "Comparison not found."
            });
        }


        // Prototype pharmacist identity.
        // Proper authentication will replace this later.
        const pharmacist = db.prepare(`
            SELECT user_id
            FROM users
            WHERE username = ?
        `).get("pharmacist");


        if (!pharmacist) {
            return res.status(500).json({
                error: "Pharmacist account not found."
            });
        }


        const previousStatus = comparison.comparison_status;
        const newStatus = "Verified";


        const updateComparison = db.prepare(`
            UPDATE medicine_comparisons
            SET
                comparison_status = ?,
                reviewed_by = ?,
                reviewed_at = CURRENT_TIMESTAMP
            WHERE comparison_id = ?
        `);


        const updateMatch = db.prepare(`
            UPDATE potential_medicine_matches
            SET match_status = ?
            WHERE match_id = ?
        `);


        const insertHistory = db.prepare(`
            INSERT INTO medicine_comparison_status_history (
                comparison_id,
                previous_status,
                new_status,
                pharmacist_id,
                comment_text
            )
            VALUES (?, ?, ?, ?, ?)
        `);


        const transaction = db.transaction(() => {

            updateComparison.run(
                newStatus,
                pharmacist.user_id,
                comparisonId
            );


            updateMatch.run(
                newStatus,
                comparison.match_id
            );


            insertHistory.run(
                comparisonId,
                previousStatus,
                newStatus,
                pharmacist.user_id,
                comment
            );
        });


        transaction();


        res.json({
            message: "Comparison verified successfully.",
            comparisonId,
            previousStatus,
            newStatus
        });

    } catch (error) {
        console.error("Error verifying comparison:", error);

        res.status(500).json({
            error: "Unable to verify comparison."
        });
    }
});


// ---------------------------------------------------------
// POST: Reject comparison
// ---------------------------------------------------------
router.post("/:comparisonId/reject", (req, res) => {
    const comparisonId = Number(req.params.comparisonId);

    const comment =
        typeof req.body.comment === "string"
            ? req.body.comment.trim()
            : "";


    if (!comment) {
        return res.status(400).json({
            error: "A rejection comment is required."
        });
    }


    try {
        const comparison = db.prepare(`
            SELECT
                comparison_id,
                comparison_status,
                match_id
            FROM medicine_comparisons
            WHERE comparison_id = ?
        `).get(comparisonId);


        if (!comparison) {
            return res.status(404).json({
                error: "Comparison not found."
            });
        }


        // Prototype pharmacist identity.
        // Proper authentication will replace this later.
        const pharmacist = db.prepare(`
            SELECT user_id
            FROM users
            WHERE username = ?
        `).get("pharmacist");


        if (!pharmacist) {
            return res.status(500).json({
                error: "Pharmacist account not found."
            });
        }


        const previousStatus = comparison.comparison_status;
        const newStatus = "Rejected";


        const updateComparison = db.prepare(`
            UPDATE medicine_comparisons
            SET
                comparison_status = ?,
                reviewed_by = ?,
                reviewed_at = CURRENT_TIMESTAMP
            WHERE comparison_id = ?
        `);


        const updateMatch = db.prepare(`
            UPDATE potential_medicine_matches
            SET match_status = ?
            WHERE match_id = ?
        `);


        const insertHistory = db.prepare(`
            INSERT INTO medicine_comparison_status_history (
                comparison_id,
                previous_status,
                new_status,
                pharmacist_id,
                comment_text
            )
            VALUES (?, ?, ?, ?, ?)
        `);


        const transaction = db.transaction(() => {

            updateComparison.run(
                newStatus,
                pharmacist.user_id,
                comparisonId
            );


            updateMatch.run(
                newStatus,
                comparison.match_id
            );


            insertHistory.run(
                comparisonId,
                previousStatus,
                newStatus,
                pharmacist.user_id,
                comment
            );
        });


        transaction();


        res.json({
            message: "Comparison rejected successfully.",
            comparisonId,
            previousStatus,
            newStatus
        });

    } catch (error) {
        console.error("Error rejecting comparison:", error);

        res.status(500).json({
            error: "Unable to reject comparison."
        });
    }
});


module.exports = router;