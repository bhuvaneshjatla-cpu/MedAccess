const express = require("express");
const router = express.Router();

const db = require("../database/db");


// =========================================================
// GET ALL STOCK RECORDS
// =========================================================

router.get("/", (req, res) => {
    try {

        const records = db.prepare(`
            SELECT
                pa.availability_id,

                pa.medicine_id,
                m.medicine_name,

                pa.pharmacy_id,
                p.pharmacy_name,

                pa.availability_status,
                pa.stock_status,
                pa.quantity,
                pa.last_updated

            FROM pharmacy_availability pa

            JOIN medicines m
                ON pa.medicine_id = m.medicine_id

            JOIN pharmacies p
                ON pa.pharmacy_id = p.pharmacy_id

            ORDER BY
                m.medicine_name,
                p.pharmacy_name
        `).all();


        res.json(records);

    } catch (error) {

        console.error(
            "Error fetching stock records:",
            error
        );

        res.status(500).json({
            error: "Unable to fetch stock records."
        });
    }
});


// =========================================================
// UPDATE STOCK
// =========================================================

router.put("/:availabilityId", (req, res) => {

    try {

        const availabilityId =
            Number(req.params.availabilityId);

        const quantity =
            Number(req.body.quantity);


        // -------------------------------------------------
        // Validate availability ID
        // -------------------------------------------------

        if (!Number.isInteger(availabilityId)) {

            return res.status(400).json({
                error: "Invalid availability record."
            });
        }


        // -------------------------------------------------
        // Validate quantity
        // -------------------------------------------------

        if (
            !Number.isInteger(quantity) ||
            quantity < 0
        ) {

            return res.status(400).json({
                error:
                    "Stock quantity must be a whole number of 0 or greater."
            });
        }


        // -------------------------------------------------
        // Check that the record exists
        // -------------------------------------------------

        const existing = db.prepare(`
            SELECT
                availability_id,
                medicine_id,
                pharmacy_id

            FROM pharmacy_availability

            WHERE availability_id = ?
        `).get(availabilityId);


        if (!existing) {

            return res.status(404).json({
                error:
                    "Stock record was not found."
            });
        }


        // -------------------------------------------------
        // Determine stock status
        // -------------------------------------------------

        let stockStatus;


        if (quantity === 0) {

            stockStatus = "Out of Stock";

        } else if (quantity <= 10) {

            stockStatus = "Low Stock";

        } else {

            stockStatus = "In Stock";
        }


        // -------------------------------------------------
        // Determine availability status
        // -------------------------------------------------

        const availabilityStatus =
            quantity > 0
                ? "Available"
                : "Unavailable";


        // -------------------------------------------------
        // Update database
        // -------------------------------------------------

        db.prepare(`
            UPDATE pharmacy_availability

            SET
                availability_status = ?,
                stock_status = ?,
                quantity = ?,
                last_updated = CURRENT_TIMESTAMP

            WHERE availability_id = ?
        `).run(
            availabilityStatus,
            stockStatus,
            quantity,
            availabilityId
        );


        // -------------------------------------------------
        // Return updated record
        // -------------------------------------------------

        const updated = db.prepare(`
            SELECT
                pa.availability_id,

                pa.medicine_id,
                m.medicine_name,

                pa.pharmacy_id,
                p.pharmacy_name,

                pa.availability_status,
                pa.stock_status,
                pa.quantity,
                pa.last_updated

            FROM pharmacy_availability pa

            JOIN medicines m
                ON pa.medicine_id = m.medicine_id

            JOIN pharmacies p
                ON pa.pharmacy_id = p.pharmacy_id

            WHERE pa.availability_id = ?
        `).get(availabilityId);


        res.json({
            message: "Stock updated successfully.",
            record: updated
        });


    } catch (error) {

        console.error(
            "Error updating stock:",
            error
        );

        res.status(500).json({
            error: "Unable to update stock."
        });
    }
});


module.exports = router;