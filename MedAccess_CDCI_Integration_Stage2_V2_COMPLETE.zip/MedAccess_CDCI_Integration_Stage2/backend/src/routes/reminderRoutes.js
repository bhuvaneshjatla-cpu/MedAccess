
const express = require("express");
const router = express.Router();
const db = require("../database/db");

// Create the reminder table if it does not already exist.
// Existing project tables and records are left untouched.
db.exec(`
    CREATE TABLE IF NOT EXISTS refill_reminders (
        reminder_id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        medicine_id INTEGER NOT NULL,
        reminder_date TEXT NOT NULL,
        reminder_time TEXT NOT NULL,
        is_recurring INTEGER NOT NULL DEFAULT 0,
        recurrence_frequency TEXT,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (medicine_id)
            REFERENCES medicines(medicine_id)
    )
`);

const validFrequencies = [
    "Daily",
    "Weekly",
    "Monthly"
];

function getReminder(reminderId) {
    return db.prepare(`
        SELECT
            r.reminder_id,
            r.username,
            r.medicine_id,
            m.medicine_name,
            r.reminder_date,
            r.reminder_time,
            r.is_recurring,
            r.recurrence_frequency,
            r.active,
            r.created_at
        FROM refill_reminders r
        JOIN medicines m
            ON m.medicine_id = r.medicine_id
        WHERE r.reminder_id = ?
    `).get(reminderId);
}

// GET /api/reminders?username=patient
// Return reminders for the requested prototype user.
router.get("/", (req, res) => {
    try {
        const username =
            typeof req.query.username === "string"
                ? req.query.username.trim()
                : "";

        if (!username) {
            return res.status(400).json({
                error: "Username is required."
            });
        }

        const reminders = db.prepare(`
            SELECT
                r.reminder_id,
                r.username,
                r.medicine_id,
                m.medicine_name,
                r.reminder_date,
                r.reminder_time,
                r.is_recurring,
                r.recurrence_frequency,
                r.active,
                r.created_at
            FROM refill_reminders r
            JOIN medicines m
                ON m.medicine_id = r.medicine_id
            WHERE r.username = ?
            ORDER BY
                r.reminder_date,
                r.reminder_time,
                r.reminder_id
        `).all(username);

        res.json(reminders);
    } catch (error) {
        console.error("Error fetching reminders:", error);
        res.status(500).json({
            error: "Unable to fetch reminders."
        });
    }
});

// POST /api/reminders
// UC-16: Create a one-time reminder.
// UC-17: Create a recurring reminder.
router.post("/", (req, res) => {
    try {
        const {
            username,
            medicine_id,
            reminder_date,
            reminder_time,
            is_recurring,
            recurrence_frequency
        } = req.body;

        const cleanUsername =
            typeof username === "string"
                ? username.trim()
                : "";

        const medicineId = Number(medicine_id);
        const recurring = is_recurring === true;

        if (!cleanUsername) {
            return res.status(400).json({
                error: "Username is required."
            });
        }

        if (cleanUsername.length > 100) {
            return res.status(400).json({
                error: "Username is too long."
            });
        }

        if (
            !Number.isInteger(medicineId) ||
            medicineId <= 0
        ) {
            return res.status(400).json({
                error: "Please select a valid medicine."
            });
        }

        if (
            typeof reminder_date !== "string" ||
            !/^\d{4}-\d{2}-\d{2}$/.test(reminder_date) ||
            !Number.isFinite(
                Date.parse(`${reminder_date}T00:00:00`)
            )
        ) {
            return res.status(400).json({
                error: "Please provide a valid reminder date."
            });
        }

        if (
            typeof reminder_time !== "string" ||
            !/^([01]\d|2[0-3]):[0-5]\d$/.test(reminder_time)
        ) {
            return res.status(400).json({
                error: "Please provide a valid reminder time."
            });
        }

        if (
            recurring &&
            !validFrequencies.includes(recurrence_frequency)
        ) {
            return res.status(400).json({
                error: "Choose Daily, Weekly, or Monthly recurrence."
            });
        }

        const medicine = db.prepare(`
            SELECT medicine_id
            FROM medicines
            WHERE medicine_id = ?
        `).get(medicineId);

        if (!medicine) {
            return res.status(404).json({
                error: "The selected medicine was not found."
            });
        }

        const result = db.prepare(`
            INSERT INTO refill_reminders (
                username,
                medicine_id,
                reminder_date,
                reminder_time,
                is_recurring,
                recurrence_frequency,
                active
            )
            VALUES (?, ?, ?, ?, ?, ?, 1)
        `).run(
            cleanUsername,
            medicineId,
            reminder_date,
            reminder_time,
            recurring ? 1 : 0,
            recurring ? recurrence_frequency : null
        );

        res.status(201).json({
            message: "Reminder created successfully.",
            reminder: getReminder(result.lastInsertRowid)
        });
    } catch (error) {
        console.error("Error creating reminder:", error);
        res.status(500).json({
            error: "Unable to create reminder."
        });
    }
});

// PATCH /api/reminders/:reminderId
// UC-17: Activate or deactivate an existing reminder.
router.patch("/:reminderId", (req, res) => {
    try {
        const reminderId = Number(req.params.reminderId);
        const { username, active } = req.body;

        const cleanUsername =
            typeof username === "string"
                ? username.trim()
                : "";

        if (
            !Number.isInteger(reminderId) ||
            reminderId <= 0
        ) {
            return res.status(400).json({
                error: "Invalid reminder ID."
            });
        }

        if (!cleanUsername) {
            return res.status(400).json({
                error: "Username is required."
            });
        }

        if (typeof active !== "boolean") {
            return res.status(400).json({
                error: "Active must be true or false."
            });
        }

        const existing = db.prepare(`
            SELECT reminder_id
            FROM refill_reminders
            WHERE reminder_id = ?
              AND username = ?
        `).get(reminderId, cleanUsername);

        if (!existing) {
            return res.status(404).json({
                error: "Reminder not found for this user."
            });
        }

        db.prepare(`
            UPDATE refill_reminders
            SET active = ?
            WHERE reminder_id = ?
              AND username = ?
        `).run(
            active ? 1 : 0,
            reminderId,
            cleanUsername
        );

        res.json({
            message: active
                ? "Reminder activated."
                : "Reminder deactivated.",
            reminder: getReminder(reminderId)
        });
    } catch (error) {
        console.error("Error updating reminder:", error);
        res.status(500).json({
            error: "Unable to update reminder."
        });
    }
});

module.exports = router;
