const express = require("express");
const router = express.Router();
const db = require("../database/db");

// GET all medicines / search medicines
router.get("/", (req, res) => {
    try {
        const search = req.query.search || "";

        const medicines = db.prepare(`
            SELECT
                medicine_id,
                medicine_name,
                active_ingredient,
                strength,
                dosage_form,
                pack_size,
                manufacturer
            FROM medicines
            WHERE medicine_name LIKE ?
               OR active_ingredient LIKE ?
            ORDER BY medicine_name
        `).all(
            `%${search}%`,
            `%${search}%`
        );

        res.json(medicines);
    } catch (error) {
        console.error("Error fetching medicines:", error);

        res.status(500).json({
            error: "Unable to fetch medicines."
        });
    }
});


// GET medicine details
router.get("/:id", (req, res) => {
    try {
        const medicineId = Number(req.params.id);

        if (!Number.isInteger(medicineId)) {
            return res.status(400).json({
                error: "Invalid medicine ID."
            });
        }

        const medicine = db.prepare(`
            SELECT
                medicine_id,
                medicine_name,
                active_ingredient,
                strength,
                dosage_form,
                pack_size,
                manufacturer
            FROM medicines
            WHERE medicine_id = ?
        `).get(medicineId);

        if (!medicine) {
            return res.status(404).json({
                error: "Medicine not found."
            });
        }

        res.json(medicine);
    } catch (error) {
        console.error("Error fetching medicine details:", error);

        res.status(500).json({
            error: "Unable to fetch medicine details."
        });
    }
});


// GET pharmacy availability for a medicine
router.get("/:id/availability", (req, res) => {
    try {
        const medicineId = Number(req.params.id);

        if (!Number.isInteger(medicineId)) {
            return res.status(400).json({
                error: "Invalid medicine ID."
            });
        }

        const records = db.prepare(`
            SELECT
                pa.availability_id,
                pa.medicine_id,
                pa.pharmacy_id,

                p.pharmacy_name,
                p.location,

                pa.availability_status,
                pa.stock_status,
                pa.quantity,
                pa.last_updated

            FROM pharmacy_availability pa

            JOIN pharmacies p
                ON pa.pharmacy_id = p.pharmacy_id

            WHERE pa.medicine_id = ?

            ORDER BY p.pharmacy_name
        `).all(medicineId);

        res.json(records);
    } catch (error) {
        console.error("Error fetching pharmacy availability:", error);

        res.status(500).json({
            error: "Unable to fetch pharmacy availability."
        });
    }
});


// GET indicative prices for a medicine
router.get("/:id/prices", (req, res) => {
    try {
        const medicineId = Number(req.params.id);

        if (!Number.isInteger(medicineId)) {
            return res.status(400).json({
                error: "Invalid medicine ID."
            });
        }

        const prices = db.prepare(`
            SELECT
                pr.price_id,
                pr.medicine_id,
                pr.pharmacy_id,

                p.pharmacy_name,
                p.location,

                pr.amount,
                pr.currency,

                pr.last_updated

            FROM prices pr

            JOIN pharmacies p
                ON pr.pharmacy_id = p.pharmacy_id

            WHERE pr.medicine_id = ?

            ORDER BY pr.amount ASC
        `).all(medicineId);

        res.json(prices);
    } catch (error) {
        console.error("Error fetching medicine prices:", error);

        res.status(500).json({
            error: "Unable to fetch medicine prices."
        });
    }
});


module.exports = router;