const express = require("express");
const router = express.Router();
const catalogueDb = require("../database/catalogueDb");
const db = require("../database/db");

// Additive migration only: this table links CDCI brand identifiers to legacy
// medicine IDs. It does not alter or delete existing inventory or catalogue rows.
db.exec(`
    CREATE TABLE IF NOT EXISTS catalogue_inventory_mappings (
        brand_identifier TEXT PRIMARY KEY,
        medicine_id INTEGER NOT NULL,
        mapping_status TEXT NOT NULL DEFAULT 'manually_confirmed',
        mapped_by TEXT,
        mapping_note TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (medicine_id) REFERENCES medicines(medicine_id) ON DELETE RESTRICT
    );
    CREATE INDEX IF NOT EXISTS idx_catalogue_inventory_mapping_medicine
        ON catalogue_inventory_mappings(medicine_id);
`);

// GET /api/catalogue?search=paracetamol&limit=25&offset=0
// Reference terminology only; this endpoint does not imply stock or price.
router.get("/", (req, res) => {
    try {
        const search = String(req.query.search || "").trim();
        const limit = Math.min(Math.max(Number.parseInt(req.query.limit, 10) || 25, 1), 100);
        const offset = Math.max(Number.parseInt(req.query.offset, 10) || 0, 0);
        if (search.length < 2) {
            return res.json({ results: [], limit, offset, message: "Enter at least two characters to search." });
        }
        const escaped = search.replace(/[\\%_]/g, "\\$&");
        const term = `%${escaped}%`;
        const rows = catalogueDb.prepare(`
            SELECT brand_identifier, brand_name, product_identifier, product_name,
                   generic_identifier, generic_name, supplier_identifier, supplier_name
            FROM catalogue_search
            WHERE brand_name LIKE ? ESCAPE '\\'
               OR product_name LIKE ? ESCAPE '\\'
               OR generic_name LIKE ? ESCAPE '\\'
               OR supplier_name LIKE ? ESCAPE '\\'
            ORDER BY brand_name COLLATE NOCASE, product_name COLLATE NOCASE
            LIMIT ? OFFSET ?
        `).all(term, term, term, term, limit, offset);
        res.json({
            results: rows.map((row) => ({ ...row, source: "CDCI Common Drug Codes for India", informationalOnly: true })),
            limit,
            offset
        });
    } catch (error) {
        console.error("CDCI catalogue search failed:", error);
        res.status(500).json({ error: "Unable to search the medicine reference catalogue." });
    }
});

// GET /api/catalogue/:brandIdentifier/inventory
// Only an explicit mapping can join a catalogue result to legacy inventory.
router.get("/:brandIdentifier/inventory", (req, res) => {
    try {
        const brandIdentifier = String(req.params.brandIdentifier || "").trim();
        if (!brandIdentifier || brandIdentifier.length > 80) {
            return res.status(400).json({ error: "Invalid catalogue brand identifier." });
        }
        const mapping = db.prepare(`
            SELECT cim.brand_identifier, cim.medicine_id, cim.mapping_status,
                   cim.mapped_by, cim.mapping_note, cim.created_at, cim.updated_at,
                   m.medicine_name, m.active_ingredient, m.strength, m.dosage_form,
                   m.pack_size, m.manufacturer
            FROM catalogue_inventory_mappings cim
            JOIN medicines m ON m.medicine_id = cim.medicine_id
            WHERE cim.brand_identifier = ?
        `).get(brandIdentifier);
        if (!mapping) {
            return res.json({ mapped: false, message: "No linked pharmacy data available.", availability: [], prices: [] });
        }
        const availability = db.prepare(`
            SELECT pa.availability_id, pa.availability_status, pa.stock_status, pa.quantity,
                   pa.last_updated, p.pharmacy_id, p.pharmacy_name, p.location
            FROM pharmacy_availability pa
            JOIN pharmacies p ON p.pharmacy_id = pa.pharmacy_id
            WHERE pa.medicine_id = ?
            ORDER BY p.pharmacy_name
        `).all(mapping.medicine_id);
        const prices = db.prepare(`
            SELECT pr.price_id, pr.amount, pr.currency, pr.last_updated,
                   p.pharmacy_id, p.pharmacy_name, p.location
            FROM prices pr
            JOIN pharmacies p ON p.pharmacy_id = pr.pharmacy_id
            WHERE pr.medicine_id = ?
            ORDER BY pr.amount ASC
        `).all(mapping.medicine_id);
        res.json({
            mapped: true,
            mapping,
            inventoryDataLabel: "DEMO DATA — not verified live pharmacy information",
            availability,
            prices
        });
    } catch (error) {
        console.error("Catalogue inventory lookup failed:", error);
        res.status(500).json({ error: "Unable to load linked pharmacy information." });
    }
});

// POST /api/catalogue/:brandIdentifier/mapping
// Explicit mapping only. Never auto-maps by name, ingredient, or identifier similarity.
// Current project uses demo-only client-side login; production must add server-side auth.
router.post("/:brandIdentifier/mapping", (req, res) => {
    try {
        const brandIdentifier = String(req.params.brandIdentifier || "").trim();
        const medicineId = Number(req.body?.medicine_id);
        const mappedBy = String(req.body?.mapped_by || "").trim().slice(0, 100);
        const mappingNote = String(req.body?.mapping_note || "").trim().slice(0, 500);
        if (!brandIdentifier || brandIdentifier.length > 80) {
            return res.status(400).json({ error: "Invalid catalogue brand identifier." });
        }
        if (!Number.isInteger(medicineId) || medicineId < 1) {
            return res.status(400).json({ error: "Choose a valid existing inventory medicine." });
        }
        const medicine = db.prepare(`SELECT medicine_id FROM medicines WHERE medicine_id = ?`).get(medicineId);
        if (!medicine) return res.status(404).json({ error: "The selected inventory medicine does not exist." });
        const exists = catalogueDb.prepare(`SELECT "Identifier" AS brand_identifier FROM brand_master WHERE "Identifier" = ?`).get(brandIdentifier);
        if (!exists) return res.status(404).json({ error: "Catalogue entry not found." });
        db.prepare(`
            INSERT INTO catalogue_inventory_mappings
                (brand_identifier, medicine_id, mapping_status, mapped_by, mapping_note, created_at, updated_at)
            VALUES (?, ?, 'manually_confirmed', ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            ON CONFLICT(brand_identifier) DO UPDATE SET
                medicine_id = excluded.medicine_id,
                mapping_status = 'manually_confirmed',
                mapped_by = excluded.mapped_by,
                mapping_note = excluded.mapping_note,
                updated_at = CURRENT_TIMESTAMP
        `).run(brandIdentifier, medicineId, mappedBy || null, mappingNote || null);
        res.status(201).json({ ok: true, message: "Catalogue-to-inventory mapping saved.", brand_identifier: brandIdentifier, medicine_id: medicineId });
    } catch (error) {
        console.error("Catalogue mapping save failed:", error);
        res.status(500).json({ error: "Unable to save the catalogue-to-inventory mapping." });
    }
});

// DELETE /api/catalogue/:brandIdentifier/mapping — removes only the link, never inventory records.
router.delete("/:brandIdentifier/mapping", (req, res) => {
    try {
        const result = db.prepare(`DELETE FROM catalogue_inventory_mappings WHERE brand_identifier = ?`).run(String(req.params.brandIdentifier || ""));
        res.json({ ok: true, removed: result.changes > 0, message: result.changes ? "Mapping removed; inventory records were not changed." : "No mapping existed." });
    } catch (error) {
        console.error("Catalogue mapping removal failed:", error);
        res.status(500).json({ error: "Unable to remove the mapping." });
    }
});

module.exports = router;
