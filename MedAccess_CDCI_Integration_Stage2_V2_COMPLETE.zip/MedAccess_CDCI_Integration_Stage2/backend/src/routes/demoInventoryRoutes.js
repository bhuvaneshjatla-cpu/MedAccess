const express = require("express");
const router = express.Router();
const inventoryDb = require("../database/inventoryDb");

// GET /api/demo-inventory?productIdentifier=<CDCI Product Identifier>
// Read-only endpoint. Every row is synthetic; it is not live pharmacy availability.
router.get("/", (req, res) => {
    try {
        const productIdentifier = String(req.query.productIdentifier || "").trim();
        if (!productIdentifier) {
            return res.status(400).json({ error: "A CDCI productIdentifier is required." });
        }
        if (productIdentifier.length > 100) {
            return res.status(400).json({ error: "Invalid CDCI product identifier." });
        }
        const results = inventoryDb.prepare(`
            SELECT inventory_item_id, pharmacy_id, pharmacy_name, locality, city, district, state,
                   cdci_product_identifier, cdci_brand_identifier, cdci_generic_identifier,
                   product_name, brand_name, generic_name, strength, dosage_form, pack_size,
                   quantity_available, stock_status, price_inr, currency, last_updated_at,
                   data_origin, is_synthetic, catalogue_match_status
            FROM v_demo_inventory
            WHERE cdci_product_identifier = ?
            ORDER BY price_inr ASC, pharmacy_name COLLATE NOCASE
        `).all(productIdentifier);
        res.json({
            source: "MedAccess synthetic inventory demo dataset",
            dataLabel: "DEMO DATA — NOT LIVE PHARMACY AVAILABILITY",
            isSynthetic: true,
            productIdentifier,
            count: results.length,
            results
        });
    } catch (error) {
        console.error("Synthetic inventory lookup failed:", error);
        res.status(500).json({ error: "Unable to load synthetic demo inventory." });
    }
});

module.exports = router;
