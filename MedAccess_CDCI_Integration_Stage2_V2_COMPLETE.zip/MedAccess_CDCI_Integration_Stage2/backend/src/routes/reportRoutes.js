
const express = require("express");
const router = express.Router();
const db = require("../database/db");

// Create the reports table if it does not already exist.
// This does not delete or replace existing database data.
db.exec(`
    CREATE TABLE IF NOT EXISTS incorrect_information_reports (
        report_id INTEGER PRIMARY KEY AUTOINCREMENT,
        medicine_id INTEGER NOT NULL,
        description TEXT NOT NULL,
        reported_by TEXT,
        status TEXT NOT NULL DEFAULT 'Open',
        resolution TEXT,
        reviewed_by TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (medicine_id)
            REFERENCES medicines(medicine_id)
    )
`);

// GET /api/reports
// Retrieve reports for the pharmacist/admin review screen.
router.get("/", (req, res) => {
    try {
        const reports = db.prepare(`
            SELECT
                r.report_id,
                r.medicine_id,
                m.medicine_name,
                r.description,
                r.reported_by,
                r.status,
                r.resolution,
                r.reviewed_by,
                r.created_at,
                r.updated_at
            FROM incorrect_information_reports r
            JOIN medicines m
                ON r.medicine_id = m.medicine_id
            ORDER BY r.created_at DESC, r.report_id DESC
        `).all();

        res.json(reports);
    } catch (error) {
        console.error("Error fetching reports:", error);

        res.status(500).json({
            error: "Unable to fetch reports."
        });
    }
});

// POST /api/reports
// UC-14: Submit a report about potentially incorrect information.
router.post("/", (req, res) => {
    try {
        const medicineId = Number(req.body.medicine_id);
        const description =
            typeof req.body.description === "string"
                ? req.body.description.trim()
                : "";
        const reportedBy =
            typeof req.body.reported_by === "string"
                ? req.body.reported_by.trim()
                : null;

        if (
            !Number.isInteger(medicineId) ||
            medicineId <= 0
        ) {
            return res.status(400).json({
                error: "Please select a valid medicine."
            });
        }

        if (!description) {
            return res.status(400).json({
                error: "Please describe the suspected issue."
            });
        }

        if (description.length > 2000) {
            return res.status(400).json({
                error: "The report description must be 2000 characters or fewer."
            });
        }

        const medicine = db.prepare(`
            SELECT medicine_id
            FROM medicines
            WHERE medicine_id = ?
        `).get(medicineId);

        if (!medicine) {
            return res.status(404).json({
                error: "The selected medicine was not found."
            });
        }

        const result = db.prepare(`
            INSERT INTO incorrect_information_reports (
                medicine_id,
                description,
                reported_by,
                status
            )
            VALUES (?, ?, ?, 'Open')
        `).run(
            medicineId,
            description,
            reportedBy || null
        );

        const report = db.prepare(`
            SELECT
                r.report_id,
                r.medicine_id,
                m.medicine_name,
                r.description,
                r.reported_by,
                r.status,
                r.resolution,
                r.reviewed_by,
                r.created_at,
                r.updated_at
            FROM incorrect_information_reports r
            JOIN medicines m
                ON r.medicine_id = m.medicine_id
            WHERE r.report_id = ?
        `).get(result.lastInsertRowid);

        res.status(201).json({
            message: "Report submitted successfully.",
            report
        });
    } catch (error) {
        console.error("Error submitting report:", error);

        res.status(500).json({
            error: "Unable to submit the report."
        });
    }
});

// PATCH /api/reports/:reportId
// UC-15: Update report status and record the review outcome.
router.patch("/:reportId", (req, res) => {
    try {
        const reportId = Number(req.params.reportId);
        const { status, resolution, reviewed_by } = req.body;

        const allowedStatuses = [
            "Open",
            "Under Review",
            "Resolved"
        ];

        if (
            !Number.isInteger(reportId) ||
            reportId <= 0
        ) {
            return res.status(400).json({
                error: "Invalid report ID."
            });
        }

        if (!allowedStatuses.includes(status)) {
            return res.status(400).json({
                error:
                    "Status must be Open, Under Review, or Resolved."
            });
        }

        const existing = db.prepare(`
            SELECT report_id
            FROM incorrect_information_reports
            WHERE report_id = ?
        `).get(reportId);

        if (!existing) {
            return res.status(404).json({
                error: "Report not found."
            });
        }

        const resolutionText =
            typeof resolution === "string"
                ? resolution.trim()
                : "";

        const reviewer =
            typeof reviewed_by === "string"
                ? reviewed_by.trim()
                : "";

        if (
            status === "Resolved" &&
            !resolutionText
        ) {
            return res.status(400).json({
                error:
                    "Please record the resolution before marking the report as Resolved."
            });
        }

        db.prepare(`
            UPDATE incorrect_information_reports
            SET
                status = ?,
                resolution = ?,
                reviewed_by = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE report_id = ?
        `).run(
            status,
            resolutionText || null,
            reviewer || null,
            reportId
        );

        const updatedReport = db.prepare(`
            SELECT
                r.report_id,
                r.medicine_id,
                m.medicine_name,
                r.description,
                r.reported_by,
                r.status,
                r.resolution,
                r.reviewed_by,
                r.created_at,
                r.updated_at
            FROM incorrect_information_reports r
            JOIN medicines m
                ON r.medicine_id = m.medicine_id
            WHERE r.report_id = ?
        `).get(reportId);

        res.json({
            message: "Report updated successfully.",
            report: updatedReport
        });
    } catch (error) {
        console.error("Error updating report:", error);

        res.status(500).json({
            error: "Unable to update the report."
        });
    }
});

module.exports = router;
