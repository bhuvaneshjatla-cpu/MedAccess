const express = require("express");
const router = express.Router();
const db = require("../database/db");

// Get all medicine price records
router.get("/", (req, res) => {
    try {
        const records = db.prepare(`
            SELECT
                pr.price_id,
                pr.medicine_id,
                m.medicine_name,
                pr.pharmacy_id,
                p.pharmacy_name,
                p.location,
                pr.amount,
                pr.currency,
                pr.last_updated
            FROM prices pr
            JOIN medicines m
                ON pr.medicine_id = m.medicine_id
            JOIN pharmacies p
                ON pr.pharmacy_id = p.pharmacy_id
            ORDER BY
                m.medicine_name,
                p.pharmacy_name
        `).all();

        res.json(records);
    } catch (error) {
        console.error("Error fetching price records:", error);

        res.status(500).json({
            error: "Unable to fetch price records."
        });
    }
});

// Update a medicine price
router.put("/:priceId", (req, res) => {
    try {
        const priceId = Number(req.params.priceId);
        const amount = Number(req.body.amount);

        if (!Number.isInteger(priceId)) {
            return res.status(400).json({
                error: "Invalid price record."
            });
        }

        if (
            !Number.isFinite(amount) ||
            amount < 0
        ) {
            return res.status(400).json({
                error:
                    "Price must be a valid number of 0 or greater."
            });
        }

        const existing = db.prepare(`
            SELECT
                price_id,
                medicine_id,
                pharmacy_id
            FROM prices
            WHERE price_id = ?
        `).get(priceId);

        if (!existing) {
            return res.status(404).json({
                error:
                    "Price record was not found."
            });
        }

        db.prepare(`
            UPDATE prices
            SET
                amount = ?,
                last_updated = CURRENT_TIMESTAMP
            WHERE price_id = ?
        `).run(
            amount,
            priceId
        );

        const updated = db.prepare(`
            SELECT
                pr.price_id,
                pr.medicine_id,
                m.medicine_name,
                pr.pharmacy_id,
                p.pharmacy_name,
                p.location,
                pr.amount,
                pr.currency,
                pr.last_updated
            FROM prices pr
            JOIN medicines m
                ON pr.medicine_id = m.medicine_id
            JOIN pharmacies p
                ON pr.pharmacy_id = p.pharmacy_id
            WHERE pr.price_id = ?
        `).get(priceId);

        res.json({
            message:
                "Medicine price updated successfully.",
            record: updated
        });
    } catch (error) {
        console.error("Error updating medicine price:", error);

        res.status(500).json({
            error:
                "Unable to update medicine price."
        });
    }
});

module.exports = router;