const express = require("express");
const cors = require("cors");

const medicineRoutes = require("./routes/medicineRoutes");
const catalogueRoutes = require("./routes/catalogueRoutes");
const matchRoutes = require("./routes/matchRoutes");
const comparisonRoutes = require("./routes/comparisonRoutes");
const stockRoutes = require("./routes/stockRoutes");
const priceRoutes = require("./routes/priceRoutes");
const reportRoutes = require("./routes/reportRoutes");
const reminderRoutes = require("./routes/reminderRoutes");
const demoInventoryRoutes = require("./routes/demoInventoryRoutes");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Health check
app.get("/", (req, res) => {
    res.json({
        message: "MedAccess backend is running"
    });
});

// CDCI reference catalogue (read-only terminology search)
app.use("/api/catalogue", catalogueRoutes);

// Separate, read-only synthetic inventory keyed by CDCI Product Identifier.
app.use("/api/demo-inventory", demoInventoryRoutes);

// Existing medicine/inventory routes retained until UI and ID relationships are migrated safely.
app.use("/api/medicines", medicineRoutes);

// Match routes
app.use("/api/matches", matchRoutes);

// Comparison routes
app.use("/api/comparisons", comparisonRoutes);

// Stock routes
app.use("/api/stock", stockRoutes);

// Price routes
app.use("/api/prices", priceRoutes);

// Report routes
app.use("/api/reports", reportRoutes);

// Reminder routes
app.use("/api/reminders", reminderRoutes);

app.listen(PORT, () => {
    console.log(`MedAccess backend running on http://localhost:${PORT}`);
});