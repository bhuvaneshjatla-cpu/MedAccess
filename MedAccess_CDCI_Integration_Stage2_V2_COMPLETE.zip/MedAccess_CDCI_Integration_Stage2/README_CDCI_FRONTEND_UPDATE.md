# MedAccess CDCI catalogue search update

## What changed
- Patient medicine search now queries `GET /api/catalogue?search=...&limit=25&offset=...`.
- Search results show product, generic description, brand description, and supplier from the CDCI reference catalogue.
- Added pagination, loading/error/empty states, and a selected-entry details panel.
- Added a clear informational-only disclaimer. Catalogue entries do not represent pharmacy stock, retail prices, authenticity checks, clinical interchangeability, or medical advice.
- Existing numeric medicine records are still loaded separately for legacy reminder, stock, price, and reporting workflows. This avoids accidentally treating CDCI identifiers as existing inventory IDs.
- The existing `database/medaccess.db` was not migrated or modified by this update.

## Run it
1. Extract this ZIP to a new folder.
2. Ensure `database/cdci_catalogue.db` exists. It is included in this package.
3. In a terminal, open `backend` and run `npm install`, then `npm start`.
4. In a second terminal, open `frontend` and run `npm install`, then `npm run dev`.
5. Open the local Vite URL (normally `http://localhost:5173`) and sign in with the existing demo account.
6. Search for `paracetamol` or another medicine name.

## Notes
- The backend catalogue connection is read-only.
- `node_modules` and `.git` are intentionally excluded from this project ZIP; install dependencies in each project folder.
- Do not remove old medicine rows until the remaining stock, price, report, match, and reminder workflows have been migrated and tested.
