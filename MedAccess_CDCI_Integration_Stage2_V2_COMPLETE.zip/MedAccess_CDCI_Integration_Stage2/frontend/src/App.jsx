import { useEffect, useState } from "react";
import "./App.css";

const API_BASE = "http://localhost:5000/api";

function App() {
    // =========================================================
    // LOGIN
    // =========================================================

    const [loggedIn, setLoggedIn] = useState(false);
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [loginError, setLoginError] = useState("");
    const [currentUser, setCurrentUser] = useState(null);

    const [view, setView] = useState("patient");

    const handleLogin = () => {
        setLoginError("");

        const demoUsers = {
            patient: {
                username: "patient",
                password: "patient123",
                role: "Patient"
            },
            pharmacist: {
                username: "pharmacist",
                password: "pharmacist123",
                role: "Pharmacist"
            },
            admin: {
                username: "admin",
                password: "admin123",
                role: "Administrator"
            }
        };

        const user = Object.values(demoUsers).find(
            (item) =>
                item.username === username.trim() &&
                item.password === password
        );

        if (!user) {
            setLoginError("Invalid username or password.");
            return;
        }

        setCurrentUser(user);
        setLoggedIn(true);

        if (user.role === "Pharmacist") {
            setView("pharmacist");
        } else if (user.role === "Administrator") {
            setView("reports");
        } else {
            setView("patient");
        }
    };

    const handleLogout = () => {
        setLoggedIn(false);
        setUsername("");
        setPassword("");
        setCurrentUser(null);
        setLoginError("");
        setView("patient");
    };

    // =========================================================
    // PATIENT STATE
    // =========================================================

    const [search, setSearch] = useState("");
    const [medicines, setMedicines] = useState([]);
    const [catalogueResults, setCatalogueResults] = useState([]);
    const [catalogueSelected, setCatalogueSelected] = useState(null);
    const [catalogueOffset, setCatalogueOffset] = useState(0);
    const [catalogueHasMore, setCatalogueHasMore] = useState(false);
    const [catalogueInventory, setCatalogueInventory] = useState(null);
    const [catalogueInventoryLoading, setCatalogueInventoryLoading] = useState(false);
    const [catalogueInventoryError, setCatalogueInventoryError] = useState("");
    const [mappingMedicineId, setMappingMedicineId] = useState("");
    const [mappingNote, setMappingNote] = useState("");
    const [mappingSaving, setMappingSaving] = useState(false);
    const [mappingMessage, setMappingMessage] = useState("");
    const [selectedMedicine, setSelectedMedicine] =
        useState(null);

    const [availability, setAvailability] = useState([]);
    const [prices, setPrices] = useState([]);

    const [medicineLoading, setMedicineLoading] =
        useState(false);
    const [availabilityLoading, setAvailabilityLoading] =
        useState(false);
    const [pricesLoading, setPricesLoading] =
        useState(false);

    const [medicineError, setMedicineError] = useState("");
    const [availabilityError, setAvailabilityError] =
        useState("");
    const [pricesError, setPricesError] = useState("");

    // =========================================================
    // PHARMACIST STATE
    // =========================================================

    const [matches, setMatches] = useState([]);
    const [selectedComparison, setSelectedComparison] =
        useState(null);
    const [comparisonDetails, setComparisonDetails] =
        useState(null);
    const [comparisonComment, setComparisonComment] =
        useState("");

    const [matchLoading, setMatchLoading] =
        useState(false);
    const [comparisonLoading, setComparisonLoading] =
        useState(false);
    const [comparisonMessage, setComparisonMessage] =
        useState("");
    const [comparisonError, setComparisonError] =
        useState("");

    // =========================================================
    // PHARMACY STAFF STATE - STOCK
    // =========================================================

    const [stockRecords, setStockRecords] = useState([]);
    const [stockLoading, setStockLoading] =
        useState(false);
    const [stockError, setStockError] = useState("");
    const [stockMessage, setStockMessage] = useState("");

    const [selectedStockMedicine, setSelectedStockMedicine] =
        useState("");
    const [selectedStockPharmacy, setSelectedStockPharmacy] =
        useState("");
    const [stockQuantity, setStockQuantity] = useState("");

    // =========================================================
    // PHARMACY STAFF STATE - PRICE / UC-13
    // =========================================================

    const [priceRecords, setPriceRecords] = useState([]);
    const [priceLoading, setPriceLoading] = useState(false);
    const [priceError, setPriceError] = useState("");
    const [priceMessage, setPriceMessage] = useState("");

    const [selectedPriceMedicine, setSelectedPriceMedicine] =
        useState("");
    const [selectedPricePharmacy, setSelectedPricePharmacy] =
        useState("");
    const [currentPrice, setCurrentPrice] = useState("");
    const [newPrice, setNewPrice] = useState("");

    // UC-14 / UC-15 report state
    const [reports, setReports] = useState([]);
    const [reportMedicineId, setReportMedicineId] = useState("");
    const [reportDescription, setReportDescription] = useState("");
    const [reportLoading, setReportLoading] = useState(false);
    const [reportError, setReportError] = useState("");
    const [reportMessage, setReportMessage] = useState("");
    const [reportDrafts, setReportDrafts] = useState({});
    const [reportResolutions, setReportResolutions] = useState({});

    // =========================================================
    // UC-16 / UC-17 REFILL REMINDERS
    // =========================================================

    const [reminders, setReminders] = useState([]);
    const [reminderMedicineId, setReminderMedicineId] = useState("");
    const [reminderDate, setReminderDate] = useState("");
    const [reminderTime, setReminderTime] = useState("09:00");
    const [reminderRecurring, setReminderRecurring] = useState(false);
    const [reminderFrequency, setReminderFrequency] = useState("Weekly");
    const [reminderLoading, setReminderLoading] = useState(false);
    const [reminderError, setReminderError] = useState("");
    const [reminderMessage, setReminderMessage] = useState("");

    const loadReminders = async () => {
        if (!currentUser?.username) return;
        try {
            setReminderLoading(true);
            setReminderError("");
            const response = await fetch(
                `${API_BASE}/reminders?username=${encodeURIComponent(currentUser.username)}`
            );
            const data = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(data.error || "Unable to load reminders. Check that the reminder API route is registered.");
            setReminders(Array.isArray(data) ? data : []);
        } catch (error) {
            console.error(error);
            setReminderError(error.message || "Unable to load reminders.");
        } finally {
            setReminderLoading(false);
        }
    };

    const createReminder = async () => {
        setReminderError("");
        setReminderMessage("");
        if (!reminderMedicineId || !reminderDate || !reminderTime) {
            setReminderError("Select a medicine and provide a date and time.");
            return;
        }
        try {
            setReminderLoading(true);
            const response = await fetch(`${API_BASE}/reminders`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    username: currentUser.username,
                    medicine_id: Number(reminderMedicineId),
                    reminder_date: reminderDate,
                    reminder_time: reminderTime,
                    is_recurring: reminderRecurring,
                    recurrence_frequency: reminderRecurring ? reminderFrequency : null
                })
            });
            const data = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(data.error || "Unable to create reminder.");
            setReminderMessage(data.message || "Reminder created successfully.");
            setReminderDate("");
            await loadReminders();
        } catch (error) {
            console.error(error);
            setReminderError(error.message || "Unable to create reminder.");
        } finally {
            setReminderLoading(false);
        }
    };

    const toggleReminder = async (reminder) => {
        setReminderError("");
        setReminderMessage("");
        try {
            setReminderLoading(true);
            const response = await fetch(`${API_BASE}/reminders/${reminder.reminder_id}`, {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    username: currentUser.username,
                    active: !(reminder.active === true || Number(reminder.active) === 1)
                })
            });
            const data = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(data.error || "Unable to update reminder.");
            setReminderMessage(data.message || "Reminder updated.");
            await loadReminders();
        } catch (error) {
            console.error(error);
            setReminderError(error.message || "Unable to update reminder.");
        } finally {
            setReminderLoading(false);
        }
    };

    // =========================================================
    // SEARCH MEDICINES
    // =========================================================

    const searchMedicines = async (nextOffset = 0, append = false) => {
        const term = search.trim();
        if (term.length < 2) {
            setCatalogueResults([]);
            setCatalogueSelected(null);
            setMedicineError(term ? "Enter at least two characters to search." : "");
            return;
        }
        try {
            setMedicineLoading(true);
            setMedicineError("");
            const response = await fetch(
                `${API_BASE}/catalogue?search=${encodeURIComponent(term)}&limit=25&offset=${nextOffset}`
            );
            const data = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(data.error || "Unable to search the CDCI catalogue.");
            const rows = Array.isArray(data.results) ? data.results : [];
            setCatalogueResults((current) => append ? [...current, ...rows] : rows);
            setCatalogueOffset(nextOffset);
            setCatalogueHasMore(rows.length === 25);
            if (!append) setCatalogueSelected(null);
        } catch (error) {
            console.error(error);
            setMedicineError(error.message || "Unable to search the medicine reference catalogue.");
        } finally {
            setMedicineLoading(false);
        }
    };

    const loadCatalogueInventory = async (item) => {
        setCatalogueSelected(item);
        setCatalogueInventory(null);
        setCatalogueInventoryError("");
        setMappingMessage("");
        setMappingMedicineId("");
        setMappingNote("");
        setCatalogueInventoryLoading(true);
        try {
            if (!item.product_identifier) {
                throw new Error("This catalogue entry has no CDCI product identifier, so demo inventory cannot be looked up.");
            }
            const response = await fetch(`${API_BASE}/demo-inventory?productIdentifier=${encodeURIComponent(item.product_identifier)}`);
            const data = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(data.error || "Unable to load synthetic demo inventory.");
            setCatalogueInventory(data);
        } catch (error) {
            setCatalogueInventoryError(error.message || "Unable to load linked pharmacy data.");
        } finally {
            setCatalogueInventoryLoading(false);
        }
    };

    const saveCatalogueMapping = async () => {
        if (!catalogueSelected || !mappingMedicineId) {
            setMappingMessage("Choose an existing inventory medicine before saving a link.");
            return;
        }
        setMappingSaving(true);
        setMappingMessage("");
        try {
            const response = await fetch(`${API_BASE}/catalogue/${encodeURIComponent(catalogueSelected.brand_identifier)}/mapping`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    medicine_id: Number(mappingMedicineId),
                    mapped_by: currentUser?.username || "",
                    mapping_note: mappingNote
                })
            });
            const data = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(data.error || "Unable to save mapping.");
            const selected = catalogueSelected;
            await loadCatalogueInventory(selected);
            setMappingMessage("Mapping saved. Pharmacy data below comes from existing MedAccess records and is labelled demo data.");
        } catch (error) {
            setMappingMessage(error.message || "Unable to save mapping.");
        } finally {
            setMappingSaving(false);
        }
    };

    const removeCatalogueMapping = async () => {
        if (!catalogueSelected) return;
        setMappingSaving(true);
        setMappingMessage("");
        try {
            const response = await fetch(`${API_BASE}/catalogue/${encodeURIComponent(catalogueSelected.brand_identifier)}/mapping`, { method: "DELETE" });
            const data = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(data.error || "Unable to remove mapping.");
            const selected = catalogueSelected;
            await loadCatalogueInventory(selected);
            setMappingMessage(data.message || "Mapping removed.");
        } catch (error) {
            setMappingMessage(error.message || "Unable to remove mapping.");
        } finally {
            setMappingSaving(false);
        }
    };

    // Existing numeric medicine IDs are still needed by legacy stock, report,
    // and reminder workflows. Load them separately from the CDCI reference search.
    const loadLegacyMedicineOptions = async () => {
        try {
            const response = await fetch(`${API_BASE}/medicines`);
            if (!response.ok) return;
            const data = await response.json();
            setMedicines(Array.isArray(data) ? data : []);
        } catch (error) {
            console.warn("Could not load existing workflow medicine options:", error);
        }
    };

    // =========================================================
    // SELECT MEDICINE
    // =========================================================

    const selectMedicine = async (medicine) => {
        setSelectedMedicine(medicine);

        setAvailability([]);
        setPrices([]);

        setAvailabilityError("");
        setPricesError("");

        await Promise.all([
            loadAvailability(medicine.medicine_id),
            loadPrices(medicine.medicine_id)
        ]);
    };

    // =========================================================
    // AVAILABILITY
    // =========================================================

    const loadAvailability = async (medicineId) => {
        try {
            setAvailabilityLoading(true);
            setAvailabilityError("");

            const response = await fetch(
                `${API_BASE}/medicines/${medicineId}/availability`
            );

            if (!response.ok) {
                const errorData =
                    await response.json().catch(
                        () => ({})
                    );

                throw new Error(
                    errorData.error ||
                        "Unable to load pharmacy availability."
                );
            }

            const data = await response.json();

            setAvailability(
                Array.isArray(data) ? data : []
            );
        } catch (error) {
            console.error(error);
            setAvailability([]);
            setAvailabilityError(error.message);
        } finally {
            setAvailabilityLoading(false);
        }
    };

    // =========================================================
    // PATIENT PRICES
    // =========================================================

    const loadPrices = async (medicineId) => {
        try {
            setPricesLoading(true);
            setPricesError("");

            const response = await fetch(
                `${API_BASE}/medicines/${medicineId}/prices`
            );

            if (!response.ok) {
                const errorData =
                    await response.json().catch(
                        () => ({})
                    );

                throw new Error(
                    errorData.error ||
                        "Unable to load medicine prices."
                );
            }

            const data = await response.json();

            setPrices(
                Array.isArray(data) ? data : []
            );
        } catch (error) {
            console.error(error);
            setPrices([]);
            setPricesError(error.message);
        } finally {
            setPricesLoading(false);
        }
    };

    // =========================================================
    // PHARMACIST MATCHES
    // =========================================================

    const loadMatches = async () => {
        try {
            setMatchLoading(true);
            setComparisonError("");

            const response = await fetch(
                `${API_BASE}/matches`
            );

            if (!response.ok) {
                throw new Error(
                    "Unable to load medicine matches."
                );
            }

            const data = await response.json();

            setMatches(
                Array.isArray(data) ? data : []
            );
        } catch (error) {
            console.error(error);
            setComparisonError(error.message);
        } finally {
            setMatchLoading(false);
        }
    };

    // =========================================================
    // COMPARISON
    // =========================================================

    const loadComparison = async (comparisonId) => {
        try {
            setComparisonLoading(true);
            setComparisonError("");
            setComparisonMessage("");

            const response = await fetch(
                `${API_BASE}/comparisons/${comparisonId}`
            );

            if (!response.ok) {
                const errorData =
                    await response.json().catch(
                        () => ({})
                    );

                throw new Error(
                    errorData.error ||
                        "Unable to load comparison."
                );
            }

            const data = await response.json();

            setComparisonDetails(data);
            setSelectedComparison(comparisonId);
            setComparisonComment("");
        } catch (error) {
            console.error(error);
            setComparisonError(error.message);
        } finally {
            setComparisonLoading(false);
        }
    };

    // =========================================================
    // VERIFY
    // =========================================================

    const verifyComparison = async () => {
        if (!selectedComparison) {
            return;
        }

        try {
            setComparisonLoading(true);
            setComparisonError("");
            setComparisonMessage("");

            const response = await fetch(
                `${API_BASE}/comparisons/${selectedComparison}/verify`,
                {
                    method: "POST",
                    headers: {
                        "Content-Type":
                            "application/json"
                    },
                    body: JSON.stringify({
                        comment:
                            comparisonComment
                    })
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(
                    data.error ||
                        "Unable to verify comparison."
                );
            }

            setComparisonMessage(
                data.message ||
                    "Medicine comparison verified successfully."
            );

            setComparisonComment("");

            await loadComparison(
                selectedComparison
            );

            await loadMatches();
        } catch (error) {
            console.error(error);
            setComparisonError(error.message);
        } finally {
            setComparisonLoading(false);
        }
    };

    // =========================================================
    // REJECT
    // =========================================================

    const rejectComparison = async () => {
        if (!selectedComparison) {
            return;
        }

        try {
            setComparisonLoading(true);
            setComparisonError("");
            setComparisonMessage("");

            const response = await fetch(
                `${API_BASE}/comparisons/${selectedComparison}/reject`,
                {
                    method: "POST",
                    headers: {
                        "Content-Type":
                            "application/json"
                    },
                    body: JSON.stringify({
                        comment:
                            comparisonComment
                    })
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(
                    data.error ||
                        "Unable to reject comparison."
                );
            }

            setComparisonMessage(
                data.message ||
                    "Medicine comparison rejected successfully."
            );

            setComparisonComment("");

            await loadComparison(
                selectedComparison
            );

            await loadMatches();
        } catch (error) {
            console.error(error);
            setComparisonError(error.message);
        } finally {
            setComparisonLoading(false);
        }
    };

    // =========================================================
    // STOCK - LOAD
    // =========================================================

    const loadStock = async () => {
        try {
            setStockLoading(true);
            setStockError("");

            const response = await fetch(
                `${API_BASE}/stock`
            );

            if (!response.ok) {
                const errorData =
                    await response.json().catch(
                        () => ({})
                    );

                throw new Error(
                    errorData.error ||
                        "Unable to load stock records."
                );
            }

            const data = await response.json();

            setStockRecords(
                Array.isArray(data) ? data : []
            );
        } catch (error) {
            console.error(error);
            setStockError(error.message);
        } finally {
            setStockLoading(false);
        }
    };

    // =========================================================
    // UC-13 PRICE - LOAD ALL PRICE RECORDS
    // =========================================================

    const loadPriceRecords = async () => {
        try {
            setPriceLoading(true);
            setPriceError("");

            const response = await fetch(
                `${API_BASE}/prices`
            );

            if (!response.ok) {
                const errorData =
                    await response.json().catch(
                        () => ({})
                    );

                throw new Error(
                    errorData.error ||
                        "Unable to load price records."
                );
            }

            const data = await response.json();

            setPriceRecords(
                Array.isArray(data) ? data : []
            );
        } catch (error) {
            console.error(error);
            setPriceError(error.message);
        } finally {
            setPriceLoading(false);
        }
    };

    // =========================================================
    // LOAD DATA AFTER LOGIN
    // =========================================================

    useEffect(() => {
        if (!loggedIn) {
            return;
        }

        loadLegacyMedicineOptions();
        loadMatches();
        loadStock();
        loadPriceRecords();
        loadReports();
        loadReminders();
    }, [loggedIn]);

    // =========================================================
    // VIEW CHANGE
    // =========================================================

    useEffect(() => {
        if (!loggedIn) {
            return;
        }

        if (view === "pharmacist") {
            loadMatches();
        }

        if (view === "staff") {
            loadStock();
            loadPriceRecords();
        }
        if (view === "reports") loadReports();
    }, [view]);

    // =========================================================
    // STOCK SELECTION
    // =========================================================

    const handleStockMedicineChange = (
        medicineId
    ) => {
        setSelectedStockMedicine(medicineId);
        setSelectedStockPharmacy("");
        setStockQuantity("");
        setStockMessage("");
        setStockError("");
    };

    const handleStockPharmacyChange = (
        pharmacyId
    ) => {
        setSelectedStockPharmacy(pharmacyId);
        setStockMessage("");
        setStockError("");

        const record = stockRecords.find(
            (item) =>
                String(item.medicine_id) ===
                    String(
                        selectedStockMedicine
                    ) &&
                String(item.pharmacy_id) ===
                    String(pharmacyId)
        );

        if (record) {
            setStockQuantity(
                record.quantity ?? 0
            );
        }
    };

    const selectedStockRecord =
        stockRecords.find(
            (item) =>
                String(item.medicine_id) ===
                    String(
                        selectedStockMedicine
                    ) &&
                String(item.pharmacy_id) ===
                    String(
                        selectedStockPharmacy
                    )
        );

    const getStockStatus = (quantity) => {
        const value = Number(quantity);

        if (value === 0) {
            return "Out of Stock";
        }

        if (value <= 10) {
            return "Low Stock";
        }

        return "In Stock";
    };

    // =========================================================
    // UPDATE STOCK
    // =========================================================

    const updateStock = async () => {
        if (!selectedStockRecord) {
            setStockError(
                "Please select a medicine and pharmacy."
            );
            return;
        }

        const quantity = Number(
            stockQuantity
        );

        if (
            !Number.isInteger(quantity) ||
            quantity < 0
        ) {
            setStockError(
                "Stock quantity must be a whole number of 0 or greater."
            );
            return;
        }

        try {
            setStockLoading(true);
            setStockError("");
            setStockMessage("");

            const response = await fetch(
                `${API_BASE}/stock/${selectedStockRecord.availability_id}`,
                {
                    method: "PUT",
                    headers: {
                        "Content-Type":
                            "application/json"
                    },
                    body: JSON.stringify({
                        quantity
                    })
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(
                    data.error ||
                        "Unable to update stock."
                );
            }

            setStockMessage(
                data.message ||
                    "Stock updated successfully."
            );

            await loadStock();

            if (
                selectedMedicine &&
                String(
                    selectedMedicine.medicine_id
                ) ===
                    String(
                        selectedStockRecord.medicine_id
                    )
            ) {
                await loadAvailability(
                    selectedStockRecord.medicine_id
                );
            }
        } catch (error) {
            console.error(error);
            setStockError(error.message);
        } finally {
            setStockLoading(false);
        }
    };

    // =========================================================
    // STOCK LISTS
    // =========================================================

    const stockMedicines = Array.from(
        new Map(
            stockRecords.map((record) => [
                record.medicine_id,
                {
                    medicine_id:
                        record.medicine_id,
                    medicine_name:
                        record.medicine_name
                }
            ])
        ).values()
    );

    const stockPharmacies =
        stockRecords.filter(
            (record) =>
                String(
                    record.medicine_id
                ) ===
                String(
                    selectedStockMedicine
                )
        );

    // =========================================================
    // UC-13 PRICE SELECTION
    // =========================================================

    const handlePriceMedicineChange = (
        medicineId
    ) => {
        setSelectedPriceMedicine(medicineId);
        setSelectedPricePharmacy("");
        setCurrentPrice("");
        setNewPrice("");
        setPriceMessage("");
        setPriceError("");
    };

    const handlePricePharmacyChange = (
        pharmacyId
    ) => {
        setSelectedPricePharmacy(pharmacyId);
        setPriceMessage("");
        setPriceError("");

        const record = priceRecords.find(
            (item) =>
                String(item.medicine_id) ===
                    String(
                        selectedPriceMedicine
                    ) &&
                String(item.pharmacy_id) ===
                    String(pharmacyId)
        );

        if (record) {
            setCurrentPrice(
                record.amount ?? ""
            );

            setNewPrice(
                record.amount ?? ""
            );
        } else {
            setCurrentPrice("");
            setNewPrice("");
        }
    };

    // =========================================================
    // UC-13 SELECTED PRICE RECORD
    // =========================================================

    const selectedPriceRecord =
        priceRecords.find(
            (item) =>
                String(item.medicine_id) ===
                    String(
                        selectedPriceMedicine
                    ) &&
                String(item.pharmacy_id) ===
                    String(
                        selectedPricePharmacy
                    )
        );

    // =========================================================
    // UC-13 UPDATE PRICE
    // =========================================================

    const updatePrice = async () => {
        if (!selectedPriceRecord) {
            setPriceError(
                "Please select a medicine and pharmacy."
            );
            return;
        }

        const amount = Number(newPrice);

        if (!Number.isFinite(amount) || amount < 0) {
            setPriceError(
                "Price must be a valid number of 0 or greater."
            );
            return;
        }

        try {
            setPriceLoading(true);
            setPriceError("");
            setPriceMessage("");

            const response = await fetch(
                `${API_BASE}/prices/${selectedPriceRecord.price_id}`,
                {
                    method: "PUT",
                    headers: {
                        "Content-Type":
                            "application/json"
                    },
                    body: JSON.stringify({
                        amount
                    })
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(
                    data.error ||
                        "Unable to update medicine price."
                );
            }

            setPriceMessage(
                data.message ||
                    "Medicine price updated successfully."
            );

            setCurrentPrice(
                data.record?.amount ?? amount
            );

            setNewPrice(
                data.record?.amount ?? amount
            );

            await loadPriceRecords();

            // Refresh patient-side prices if
            // the currently selected medicine
            // is the same medicine being updated.
            if (
                selectedMedicine &&
                String(
                    selectedMedicine.medicine_id
                ) ===
                    String(
                        selectedPriceRecord.medicine_id
                    )
            ) {
                await loadPrices(
                    selectedPriceRecord.medicine_id
                );
            }
        } catch (error) {
            console.error(error);
            setPriceError(error.message);
        } finally {
            setPriceLoading(false);
        }
    };

    // =========================================================
    // UC-13 PRICE LISTS
    // =========================================================

    const priceMedicines = Array.from(
        new Map(
            priceRecords.map((record) => [
                record.medicine_id,
                {
                    medicine_id:
                        record.medicine_id,
                    medicine_name:
                        record.medicine_name
                }
            ])
        ).values()
    );

    const pricePharmacies =
        priceRecords.filter(
            (record) =>
                String(
                    record.medicine_id
                ) ===
                String(
                    selectedPriceMedicine
                )
        );

    const loadReports = async () => {
        try {
            setReportLoading(true); setReportError("");
            const response = await fetch(`${API_BASE}/reports`);
            const data = await response.json();
            if (!response.ok) throw new Error(data.error || "Unable to load reports.");
            setReports(Array.isArray(data) ? data : []);
        } catch (error) { console.error(error); setReportError(error.message); }
        finally { setReportLoading(false); }
    };

    const submitReport = async () => {
        const medicineId = Number(reportMedicineId);
        const description = reportDescription.trim();
        if (!Number.isInteger(medicineId) || medicineId <= 0) return setReportError("Please select a medicine.");
        if (!description) return setReportError("Please describe the suspected issue.");
        try {
            setReportLoading(true); setReportError(""); setReportMessage("");
            const response = await fetch(`${API_BASE}/reports`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ medicine_id: medicineId, description, reported_by: currentUser?.username || "" })
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error || "Unable to submit the report.");
            setReportMessage(data.message || "Report submitted successfully.");
            setReportDescription(""); setReportMedicineId("");
            await loadReports();
        } catch (error) { console.error(error); setReportError(error.message); }
        finally { setReportLoading(false); }
    };

    const updateReport = async (report) => {
        const status = reportDrafts[report.report_id] ?? report.status;
        const resolution = (reportResolutions[report.report_id] ?? report.resolution ?? "").trim();
        if (status === "Resolved" && !resolution) return setReportError(`Enter a resolution for report #${report.report_id} before marking it Resolved.`);
        try {
            setReportLoading(true); setReportError(""); setReportMessage("");
            const response = await fetch(`${API_BASE}/reports/${report.report_id}`, {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ status, resolution, reviewed_by: currentUser?.username || "" })
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error || "Unable to update the report.");
            setReportMessage(`Report #${report.report_id} updated successfully.`);
            await loadReports();
        } catch (error) { console.error(error); setReportError(error.message); }
        finally { setReportLoading(false); }
    };

    // =========================================================
    // LOGIN SCREEN
    // =========================================================

    if (!loggedIn) {
        return (
            <div className="login-page">
                <div className="login-card">
                    <div className="login-logo">
                        MedAccess
                    </div>

                    <h1>Welcome to MedAccess</h1>

                    <p className="login-subtitle">
                        Medicine information,
                        availability and
                        affordability assistant
                    </p>

                    <div className="login-form">
                        <label>
                            Username
                        </label>

                        <input
                            type="text"
                            value={username}
                            onChange={(e) =>
                                setUsername(
                                    e.target.value
                                )
                            }
                            placeholder="Enter username"
                            onKeyDown={(e) => {
                                if (
                                    e.key ===
                                    "Enter"
                                ) {
                                    handleLogin();
                                }
                            }}
                        />

                        <label>
                            Password
                        </label>

                        <input
                            type="password"
                            value={password}
                            onChange={(e) =>
                                setPassword(
                                    e.target.value
                                )
                            }
                            placeholder="Enter password"
                            onKeyDown={(e) => {
                                if (
                                    e.key ===
                                    "Enter"
                                ) {
                                    handleLogin();
                                }
                            }}
                        />

                        {loginError && (
                            <div className="error login-error">
                                {loginError}
                            </div>
                        )}

                        <button
                            className="login-button"
                            onClick={
                                handleLogin
                            }
                        >
                            Login
                        </button>
                    </div>

                    <div className="demo-accounts">
                        <h3>
                            Prototype Demo Accounts
                        </h3>

                        <p>
                            <strong>
                                Patient:
                            </strong>{" "}
                            patient / patient123
                        </p>

                        <p>
                            <strong>
                                Pharmacist:
                            </strong>{" "}
                            pharmacist /
                            pharmacist123
                        </p>

                        <p>
                            <strong>
                                Administrator:
                            </strong>{" "}
                            admin / admin123
                        </p>
                    </div>

                    <div className="login-footer">
                        Information only. MedAccess
                        does not dispense or sell
                        medicines.
                    </div>
                </div>
            </div>
        );
    }

    // =========================================================
    // PATIENT VIEW
    // =========================================================

    const renderPatientView = () => (
        <>
            <section className="section catalogue-search-section">
                <div className="catalogue-heading-row">
                    <div>
                        <span className="eyebrow">CDCI REFERENCE CATALOGUE</span>
                        <h2>Find medicine information</h2>
                        <p className="catalogue-intro">Search medicine names, products, generic descriptions, or suppliers in the Indian common drug-code catalogue.</p>
                    </div>
                    <span className="reference-badge"><span className="status-dot" /> Reference data</span>
                </div>

                <form className="catalogue-search-form" onSubmit={(e) => { e.preventDefault(); searchMedicines(0, false); }}>
                    <div className="catalogue-search-input-wrap">
                        <span className="search-symbol" aria-hidden="true">⌕</span>
                        <input
                            type="search"
                            aria-label="Search the medicine catalogue"
                            placeholder="Try paracetamol, cetirizine, a brand, or a supplier"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                    </div>
                    <button type="submit" disabled={medicineLoading}>{medicineLoading ? "Searching…" : "Search catalogue"}</button>
                </form>
                <div className="search-hint">Enter at least 2 characters. Results are reference information, not pharmacy stock or medical advice.</div>

                {medicineLoading && <div className="catalogue-state"><span className="loading-spinner" /> Searching the CDCI catalogue…</div>}
                {medicineError && <div className="catalogue-state catalogue-error" role="alert"><strong>Search unavailable</strong><span>{medicineError}</span><button type="button" className="subtle-button" onClick={() => searchMedicines(0, false)}>Try again</button></div>}

                {!medicineLoading && !medicineError && search.trim().length >= 2 && catalogueResults.length === 0 && (
                    <div className="catalogue-state"><strong>No matching entries found</strong><span>Try a shorter name or search by product, generic description, or supplier.</span></div>
                )}

                {catalogueResults.length > 0 && <>
                    <div className="results-heading"><div><h3>Catalogue matches</h3><p>Showing {catalogueResults.length} result{catalogueResults.length === 1 ? "" : "s"}{catalogueHasMore ? " · more may be available" : ""}</p></div><span className="results-source">Source: CDCI</span></div>
                    <div className="medicine-list catalogue-results-grid">
                        {catalogueResults.map((item) => (
                            <button type="button" key={item.brand_identifier} className={`medicine-item catalogue-result-card ${catalogueSelected?.brand_identifier === item.brand_identifier ? "catalogue-result-selected" : ""}`} onClick={() => loadCatalogueInventory(item)}>
                                <span className="result-card-topline"><span className="result-type">MEDICINE ENTRY</span><span className="result-arrow">↗</span></span>
                                <strong>{item.product_name || item.brand_name || "Unnamed product"}</strong>
                                <span className="result-generic">{item.generic_name || "Generic description not provided"}</span>
                                <span className="result-brand">{item.brand_name || "Brand description not provided"}</span>
                                <span className="result-supplier"><span className="supplier-icon">▦</span>{item.supplier_name || "Supplier not listed"}</span>
                            </button>
                        ))}
                    </div>
                    {catalogueHasMore && <div className="load-more-wrap"><button className="load-more-button" type="button" disabled={medicineLoading} onClick={() => searchMedicines(catalogueOffset + 25, true)}>Load more results</button></div>}
                </>}

                {catalogueSelected && <div className="catalogue-detail-panel">
                    <div className="catalogue-detail-title"><div><span className="eyebrow">SELECTED CATALOGUE ENTRY</span><h3>{catalogueSelected.product_name || "Medicine product"}</h3></div><button className="detail-close" type="button" onClick={() => setCatalogueSelected(null)} aria-label="Close selected entry">×</button></div>
                    <div className="catalogue-detail-grid">
                        <div><span>Generic description</span><strong>{catalogueSelected.generic_name || "Not listed"}</strong></div>
                        <div><span>Brand description</span><strong>{catalogueSelected.brand_name || "Not listed"}</strong></div>
                        <div><span>Supplier</span><strong>{catalogueSelected.supplier_name || "Not listed"}</strong></div>
                        <div><span>Catalogue identifiers</span><strong>Brand: {catalogueSelected.brand_identifier || "—"}<br />Product: {catalogueSelected.product_identifier || "—"}<br />Generic: {catalogueSelected.generic_identifier || "—"}</strong></div>
                    </div>
                    <p className="catalogue-disclaimer">This entry is informational only. The demo inventory below is synthetic and does not confirm real pharmacy availability, price, product authenticity, or clinical interchangeability. Confirm medicine details with a qualified pharmacist.</p>
                    <div className="linked-inventory-panel">
                        <div className="linked-inventory-heading"><h4>Pharmacy availability &amp; prices</h4><span className="results-source">Synthetic demo inventory</span></div>
                        {catalogueInventoryLoading && <p>Loading synthetic demo inventory…</p>}
                        {catalogueInventoryError && <p className="catalogue-error-text" role="alert">{catalogueInventoryError}</p>}
                        {!catalogueInventoryLoading && !catalogueInventoryError && catalogueInventory && <>
                            <div className="demo-data-notice"><strong>{catalogueInventory.dataLabel || "DEMO DATA — NOT LIVE PHARMACY AVAILABILITY"}</strong><span>All pharmacy names, quantities, prices, and timestamps in this section are synthetic test data. They do not describe real pharmacy stock or prices.</span></div>
                            {catalogueInventory.results?.length ? <div className="table-container"><table><thead><tr><th>Demo pharmacy</th><th>Locality</th><th>District</th><th>Stock status</th><th>Quantity</th><th>Demo price</th><th>Last updated</th></tr></thead><tbody>{catalogueInventory.results.map((record) => <tr key={record.inventory_item_id}><td>{record.pharmacy_name}</td><td>{record.locality}</td><td>{record.district}</td><td>{record.stock_status?.replaceAll("_", " ")}</td><td>{record.quantity_available}</td><td>{record.currency} {Number(record.price_inr).toFixed(2)}</td><td>{record.last_updated_at || "Not recorded"}</td></tr>)}</tbody></table></div> : <div className="catalogue-state"><strong>No demo inventory records for this catalogue product</strong><span>This product is present in the CDCI reference catalogue, but it was not selected for the seeded synthetic inventory dataset. This does not indicate real-world availability or unavailability.</span></div>}
                        </>}
                    </div>
                </div>}
            </section>

            {selectedMedicine && (
                <>
                    <section className="section">
                        <h2>
                            Medicine Details
                        </h2>

                        <div className="details-grid">
                            <div>
                                <strong>
                                    Medicine Name
                                </strong>

                                <span>
                                    {
                                        selectedMedicine.medicine_name
                                    }
                                </span>
                            </div>

                            <div>
                                <strong>
                                    Active Ingredient
                                </strong>

                                <span>
                                    {
                                        selectedMedicine.active_ingredient
                                    }
                                </span>
                            </div>

                            <div>
                                <strong>
                                    Strength
                                </strong>

                                <span>
                                    {
                                        selectedMedicine.strength
                                    }
                                </span>
                            </div>

                            <div>
                                <strong>
                                    Dosage Form
                                </strong>

                                <span>
                                    {
                                        selectedMedicine.dosage_form
                                    }
                                </span>
                            </div>

                            <div>
                                <strong>
                                    Pack Size
                                </strong>

                                <span>
                                    {
                                        selectedMedicine.pack_size
                                    }
                                </span>
                            </div>

                            <div>
                                <strong>
                                    Manufacturer
                                </strong>

                                <span>
                                    {
                                        selectedMedicine.manufacturer
                                    }
                                </span>
                            </div>
                        </div>
                    </section>

                    <section className="section">
                        <h2>
                            Pharmacy Availability
                        </h2>

                        {availabilityLoading && (
                            <p>
                                Loading pharmacy
                                availability...
                            </p>
                        )}

                        {availabilityError && (
                            <p className="error">
                                {
                                    availabilityError
                                }
                            </p>
                        )}

                        {!availabilityLoading &&
                            !availabilityError &&
                            availability.length ===
                                0 && (
                                <p>
                                    No availability
                                    records found
                                    for this
                                    medicine.
                                </p>
                            )}

                        {!availabilityLoading &&
                            availability.length >
                                0 && (
                                <div className="table-container">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>
                                                    Pharmacy
                                                </th>

                                                <th>
                                                    Location
                                                </th>

                                                <th>
                                                    Availability
                                                </th>

                                                <th>
                                                    Stock Status
                                                </th>

                                                <th>
                                                    Quantity
                                                </th>

                                                <th>
                                                    Last Updated
                                                </th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            {availability.map(
                                                (
                                                    record
                                                ) => (
                                                    <tr
                                                        key={
                                                            record.availability_id
                                                        }
                                                    >
                                                        <td>
                                                            {
                                                                record.pharmacy_name
                                                            }
                                                        </td>

                                                        <td>
                                                            {
                                                                record.location
                                                            }
                                                        </td>

                                                        <td>
                                                            {
                                                                record.availability_status
                                                            }
                                                        </td>

                                                        <td>
                                                            {record.stock_status ||
                                                                getStockStatus(
                                                                    record.quantity
                                                                )}
                                                        </td>

                                                        <td>
                                                            {record.quantity ??
                                                                0}
                                                        </td>

                                                        <td>
                                                            {record.last_updated
                                                                ? new Date(
                                                                      record.last_updated
                                                                  ).toLocaleString()
                                                                : "—"}
                                                        </td>
                                                    </tr>
                                                )
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                            )}
                    </section>

                    <section className="section">
                        <h2>
                            Indicative Prices
                        </h2>

                        {pricesLoading && (
                            <p>
                                Loading indicative
                                prices...
                            </p>
                        )}

                        {pricesError && (
                            <p className="error">
                                {pricesError}
                            </p>
                        )}

                        {!pricesLoading &&
                            !pricesError &&
                            prices.length ===
                                0 && (
                                <p>
                                    No price records
                                    found.
                                </p>
                            )}

                        {!pricesLoading &&
                            prices.length >
                                0 && (
                                <div className="table-container">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>
                                                    Pharmacy
                                                </th>

                                                <th>
                                                    Location
                                                </th>

                                                <th>
                                                    Indicative
                                                    Price
                                                </th>

                                                <th>
                                                    Last
                                                    Updated
                                                </th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            {prices.map(
                                                (
                                                    price
                                                ) => (
                                                    <tr
                                                        key={
                                                            price.price_id
                                                        }
                                                    >
                                                        <td>
                                                            {
                                                                price.pharmacy_name
                                                            }
                                                        </td>

                                                        <td>
                                                            {
                                                                price.location
                                                            }
                                                        </td>

                                                        <td>
                                                            {
                                                                price.currency
                                                            }{" "}
                                                            {
                                                                price.amount
                                                            }
                                                        </td>

                                                        <td>
                                                            {price.last_updated
                                                                ? new Date(
                                                                      price.last_updated
                                                                  ).toLocaleString()
                                                                : "—"}
                                                        </td>
                                                    </tr>
                                                )
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                            )}
                    </section>

                    <section className="section">
                        <h2>
                            Compare Pharmacy
                            Prices
                        </h2>

                        {prices.length >
                        0 ? (
                            <div className="comparison-box">
                                {prices.map(
                                    (
                                        price,
                                        index
                                    ) => (
                                        <div
                                            key={
                                                price.price_id
                                            }
                                            className="comparison-row"
                                        >
                                            <span>
                                                {
                                                    price.pharmacy_name
                                                }
                                            </span>

                                            <strong>
                                                {
                                                    price.currency
                                                }{" "}
                                                {
                                                    price.amount
                                                }
                                            </strong>

                                            {index ===
                                                0 && (
                                                <span className="lowest-price">
                                                    Lowest
                                                    indicative
                                                    price
                                                </span>
                                            )}
                                        </div>
                                    )
                                )}
                            </div>
                        ) : (
                            <p>
                                Prices for the
                                selected medicine
                                are compared
                                across available
                                pharmacy records
                                above.
                            </p>
                        )}
                    </section>
                </>
            )}
            <section className="section">
                <h2>Refill Reminders</h2>
                <p>Create a one-time or recurring reminder for your own convenience. These are saved records only; MedAccess does not send notifications or provide dosing or treatment advice.</p>
                <div className="form-grid">
                    <div>
                        <label htmlFor="reminder-medicine">Medicine</label>
                        <select id="reminder-medicine" value={reminderMedicineId} onChange={(e) => setReminderMedicineId(e.target.value)}>
                            <option value="">Select medicine</option>
                            {medicines.map((medicine) => <option key={medicine.medicine_id} value={medicine.medicine_id}>{medicine.medicine_name}{medicine.strength ? ` — ${medicine.strength}` : ""}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="reminder-date">Reminder date</label>
                        <input id="reminder-date" type="date" min={new Date().toLocaleDateString("en-CA")} value={reminderDate} onChange={(e) => setReminderDate(e.target.value)} />
                    </div>
                    <div>
                        <label htmlFor="reminder-time">Reminder time</label>
                        <input id="reminder-time" type="time" value={reminderTime} onChange={(e) => setReminderTime(e.target.value)} />
                    </div>
                    <div>
                        <label htmlFor="reminder-type">Reminder type</label>
                        <select id="reminder-type" value={reminderRecurring ? "recurring" : "once"} onChange={(e) => setReminderRecurring(e.target.value === "recurring")}>
                            <option value="once">One-time reminder</option>
                            <option value="recurring">Recurring reminder</option>
                        </select>
                    </div>
                    {reminderRecurring && <div>
                        <label htmlFor="reminder-frequency">Repeat frequency</label>
                        <select id="reminder-frequency" value={reminderFrequency} onChange={(e) => setReminderFrequency(e.target.value)}>
                            <option value="Daily">Daily</option><option value="Weekly">Weekly</option><option value="Monthly">Monthly</option>
                        </select>
                    </div>}
                </div>
                <div className="button-row">
                    <button onClick={createReminder} disabled={reminderLoading}>{reminderLoading ? "Please wait..." : "Create Reminder"}</button>
                    <button onClick={loadReminders} disabled={reminderLoading}>Refresh Reminders</button>
                </div>
                {reminderMessage && <p className="success">{reminderMessage}</p>}
                {reminderError && <p className="error">{reminderError}</p>}
                <h3>My Reminders</h3>
                {reminders.length === 0 ? <p>{reminderLoading ? "Loading reminders..." : "No reminders have been created yet."}</p> : <div className="table-container"><table>
                    <thead><tr><th>Medicine</th><th>Date</th><th>Time</th><th>Type</th><th>Status</th><th>Action</th></tr></thead>
                    <tbody>{reminders.map((reminder) => {
                        const active = reminder.active === true || Number(reminder.active) === 1;
                        return <tr key={reminder.reminder_id}>
                            <td>{reminder.medicine_name || `Medicine #${reminder.medicine_id}`}</td>
                            <td>{reminder.reminder_date}</td>
                            <td>{reminder.reminder_time}</td>
                            <td>{Number(reminder.is_recurring) === 1 ? `Recurring (${reminder.recurrence_frequency || "—"})` : "One-time"}</td>
                            <td>{active ? "Active" : "Inactive"}</td>
                            <td><button onClick={() => toggleReminder(reminder)} disabled={reminderLoading}>{active ? "Deactivate" : "Activate"}</button></td>
                        </tr>;
                    })}</tbody>
                </table></div>}
            </section>

            <section className="section">
                <h2>Report Incorrect Information</h2>
                <p>Report information that appears incorrect or outdated. Reports do not automatically change medicine details, stock, or prices.</p>
                <div className="form-grid">
                    <div>
                        <label htmlFor="report-medicine">Medicine</label>
                        <select id="report-medicine" value={reportMedicineId} onChange={(e) => { setReportMedicineId(e.target.value); setReportError(""); setReportMessage(""); }}>
                            <option value="">Select medicine</option>
                            {medicines.map((medicine) => <option key={medicine.medicine_id} value={medicine.medicine_id}>{medicine.medicine_name}{medicine.strength ? ` — ${medicine.strength}` : ""}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="report-description">Describe the suspected issue</label>
                        <textarea id="report-description" rows="4" maxLength="2000" value={reportDescription} onChange={(e) => setReportDescription(e.target.value)} placeholder="For example: the pharmacy confirmed this medicine is out of stock." />
                        <small>{reportDescription.length}/2000 characters</small>
                    </div>
                </div>
                <div className="button-row">
                    <button onClick={submitReport} disabled={reportLoading}>{reportLoading ? "Submitting..." : "Submit Report"}</button>
                    <button onClick={loadReports} disabled={reportLoading}>Refresh My Reports</button>
                </div>
                {reportMessage && <p className="success">{reportMessage}</p>}
                {reportError && <p className="error">{reportError}</p>}
                <h3>My Submitted Reports</h3>
                {reports.filter((r) => String(r.reported_by || "") === String(currentUser?.username || "")).length === 0
                    ? <p>You have not submitted any reports yet.</p>
                    : <div className="table-container"><table>
                        <thead><tr><th>ID</th><th>Medicine</th><th>Description</th><th>Status</th><th>Submitted</th><th>Resolution</th></tr></thead>
                        <tbody>{reports.filter((r) => String(r.reported_by || "") === String(currentUser?.username || "")).map((r) => <tr key={r.report_id}><td>#{r.report_id}</td><td>{r.medicine_name}</td><td>{r.description}</td><td>{r.status}</td><td>{r.created_at || "—"}</td><td>{r.resolution || "—"}</td></tr>)}</tbody>
                    </table></div>}
            </section>
        </>
    );

    // =========================================================
    // PHARMACIST VIEW
    // =========================================================

    const renderPharmacistView =
        () => (
            <section className="section">
                <h2>
                    Pharmacist Dashboard
                </h2>

                <button
                    onClick={
                        loadMatches
                    }
                >
                    Refresh Matches
                </button>

                {matchLoading && (
                    <p>
                        Loading medicine
                        comparisons...
                    </p>
                )}

                {comparisonError && (
                    <p className="error">
                        {
                            comparisonError
                        }
                    </p>
                )}

                {!matchLoading &&
                    matches.length ===
                        0 && (
                        <p>
                            No medicine
                            comparison
                            records found.
                        </p>
                    )}

                {matches.length >
                    0 && (
                    <div className="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>
                                        Medicine A
                                    </th>

                                    <th>
                                        Medicine B
                                    </th>

                                    <th>
                                        Status
                                    </th>

                                    <th>
                                        Action
                                    </th>
                                </tr>
                            </thead>

                            <tbody>
                                {matches.map(
                                    (
                                        match
                                    ) => (
                                        <tr
                                            key={
                                                match.match_id
                                            }
                                        >
                                            <td>
                                                {
                                                    match.medicine_a_name
                                                }
                                            </td>

                                            <td>
                                                {
                                                    match.medicine_b_name
                                                }
                                            </td>

                                            <td>
                                                {
                                                    match.status
                                                }
                                            </td>

                                            <td>
                                                <button
                                                    onClick={() =>
                                                        loadComparison(
                                                            match.comparison_id
                                                        )
                                                    }
                                                >
                                                    Review
                                                </button>
                                            </td>
                                        </tr>
                                    )
                                )}
                            </tbody>
                        </table>
                    </div>
                )}

                {comparisonDetails && (
                    <div className="review-panel">
                        <h3>
                            Review Medicine
                            Comparison
                        </h3>

                        <p>
                            <strong>
                                Medicine A:
                            </strong>{" "}
                            {
                                comparisonDetails.medicine_a_name
                            }
                        </p>

                        <p>
                            <strong>
                                Medicine B:
                            </strong>{" "}
                            {
                                comparisonDetails.medicine_b_name
                            }
                        </p>

                        <p>
                            <strong>
                                Current Status:
                            </strong>{" "}
                            {
                                comparisonDetails.status
                            }
                        </p>

                        <h3>
                            Verification
                            Comment
                        </h3>

                        <textarea
                            value={
                                comparisonComment
                            }
                            onChange={(e) =>
                                setComparisonComment(
                                    e.target.value
                                )
                            }
                            placeholder="Enter a verification comment..."
                            rows="4"
                        />

                        <div className="button-row">
                            <button
                                onClick={
                                    verifyComparison
                                }
                                disabled={
                                    comparisonLoading
                                }
                            >
                                Verify
                            </button>

                            <button
                                onClick={
                                    rejectComparison
                                }
                                disabled={
                                    comparisonLoading
                                }
                            >
                                Reject
                            </button>
                        </div>

                        {comparisonMessage && (
                            <p className="success">
                                {
                                    comparisonMessage
                                }
                            </p>
                        )}

                        <h3>
                            Status History
                        </h3>

                        {comparisonDetails.statusHistory &&
                        comparisonDetails
                            .statusHistory
                            .length >
                            0 ? (
                            <div className="history-list">
                                {comparisonDetails.statusHistory.map(
                                    (
                                        history
                                    ) => (
                                        <div
                                            className="history-item"
                                            key={
                                                history.history_id
                                            }
                                        >
                                            <strong>
                                                {
                                                    history.new_status
                                                }
                                            </strong>

                                            <span>
                                                {
                                                    history.previous_status
                                                }{" "}
                                                →{" "}
                                                {
                                                    history.new_status
                                                }
                                            </span>

                                            <span>
                                                {
                                                    history.username
                                                }
                                            </span>

                                            <span>
                                                {
                                                    history.comment ||
                                                    "No comment"
                                                }
                                            </span>

                                            <small>
                                                {
                                                    history.created_at
                                                }
                                            </small>
                                        </div>
                                    )
                                )}
                            </div>
                        ) : (
                            <p>
                                No status history
                                available.
                            </p>
                        )}
                    </div>
                )}
            </section>
        );

    const renderReportsView = () => (
        <section className="section">
            <h2>Incorrect Information Reports</h2>
            <p>Review reports and record the outcome. This does not automatically modify medicine, stock, or price records.</p>
            <div className="button-row"><button onClick={loadReports} disabled={reportLoading}>Refresh Reports</button></div>
            {reportMessage && <p className="success">{reportMessage}</p>}
            {reportError && <p className="error">{reportError}</p>}
            {reportLoading && <p>Loading reports...</p>}
            {!reportLoading && reports.length === 0 && <p>No reports have been submitted.</p>}
            {reports.map((r) => <div className="review-panel" key={r.report_id}>
                <h3>Report #{r.report_id}: {r.medicine_name}</h3>
                <p><strong>Reported by:</strong> {r.reported_by || "Not provided"}</p>
                <p><strong>Submitted:</strong> {r.created_at || "—"}</p>
                <p><strong>Issue reported:</strong> {r.description}</p>
                <p><strong>Current status:</strong> {r.status}</p>
                <div className="form-grid">
                    <div><label htmlFor={`report-status-${r.report_id}`}>Update status</label>
                        <select id={`report-status-${r.report_id}`} value={reportDrafts[r.report_id] ?? r.status} onChange={(e) => setReportDrafts((prev) => ({ ...prev, [r.report_id]: e.target.value }))}>
                            <option value="Open">Open</option><option value="Under Review">Under Review</option><option value="Resolved">Resolved</option>
                        </select>
                    </div>
                    <div><label htmlFor={`report-resolution-${r.report_id}`}>Review notes / resolution</label>
                        <textarea id={`report-resolution-${r.report_id}`} rows="3" maxLength="2000" value={reportResolutions[r.report_id] ?? r.resolution ?? ""} onChange={(e) => setReportResolutions((prev) => ({ ...prev, [r.report_id]: e.target.value }))} placeholder="Record what was checked or how the issue was resolved." />
                    </div>
                </div>
                <p><small>Last reviewed by: {r.reviewed_by || "Not reviewed yet"}</small></p>
                <button onClick={() => updateReport(r)} disabled={reportLoading}>Save Review</button>
            </div>)}
        </section>
    );

    // =========================================================
    // PHARMACY STAFF VIEW
    // =========================================================

    const renderStaffView =
        () => (
            <section className="section">
                <h2>
                    Pharmacy Staff Dashboard
                </h2>

                {/* =================================================
                    UC-12 - UPDATE MEDICINE STOCK
                ================================================= */}

                <div className="staff-subsection">
                    <h3>
                        Update Medicine Stock
                    </h3>

                    <p>
                        Update medicine stock
                        availability for a
                        pharmacy.
                    </p>

                    <div className="form-grid">
                        <div>
                            <label>
                                Medicine
                            </label>

                            <select
                                value={
                                    selectedStockMedicine
                                }
                                onChange={(e) =>
                                    handleStockMedicineChange(
                                        e.target
                                            .value
                                    )
                                }
                            >
                                <option value="">
                                    Select medicine
                                </option>

                                {stockMedicines.map(
                                    (
                                        medicine
                                    ) => (
                                        <option
                                            key={
                                                medicine.medicine_id
                                            }
                                            value={
                                                medicine.medicine_id
                                            }
                                        >
                                            {
                                                medicine.medicine_name
                                            }
                                        </option>
                                    )
                                )}
                            </select>
                        </div>

                        <div>
                            <label>
                                Pharmacy
                            </label>

                            <select
                                value={
                                    selectedStockPharmacy
                                }
                                onChange={(e) =>
                                    handleStockPharmacyChange(
                                        e.target
                                            .value
                                    )
                                }
                                disabled={
                                    !selectedStockMedicine
                                }
                            >
                                <option value="">
                                    Select pharmacy
                                </option>

                                {stockPharmacies.map(
                                    (
                                        record
                                    ) => (
                                        <option
                                            key={
                                                record.pharmacy_id
                                            }
                                            value={
                                                record.pharmacy_id
                                            }
                                        >
                                            {
                                                record.pharmacy_name
                                            }
                                        </option>
                                    )
                                )}
                            </select>
                        </div>

                        <div>
                            <label>
                                Current Stock
                            </label>

                            <input
                                type="text"
                                value={
                                    selectedStockRecord
                                        ? selectedStockRecord.quantity
                                        : ""
                                }
                                readOnly
                                placeholder="—"
                            />
                        </div>

                        <div>
                            <label>
                                New Quantity
                            </label>

                            <input
                                type="number"
                                min="0"
                                step="1"
                                value={
                                    stockQuantity
                                }
                                onChange={(e) =>
                                    setStockQuantity(
                                        e.target
                                            .value
                                    )
                                }
                                disabled={
                                    !selectedStockRecord
                                }
                            />
                        </div>

                        <div>
                            <label>
                                Stock Status
                            </label>

                            <input
                                type="text"
                                value={
                                    stockQuantity !==
                                    ""
                                        ? getStockStatus(
                                              stockQuantity
                                          )
                                        : ""
                                }
                                readOnly
                                placeholder="—"
                            />
                        </div>
                    </div>

                    <div className="button-row">
                        <button
                            onClick={
                                updateStock
                            }
                            disabled={
                                stockLoading ||
                                !selectedStockRecord
                            }
                        >
                            Update Stock
                        </button>

                        <button
                            onClick={
                                loadStock
                            }
                            disabled={
                                stockLoading
                            }
                        >
                            Refresh
                        </button>
                    </div>

                    {stockMessage && (
                        <p className="success">
                            {stockMessage}
                        </p>
                    )}

                    {stockError && (
                        <p className="error">
                            {stockError}
                        </p>
                    )}

                    <h3>
                        Current Stock Records
                    </h3>

                    {stockLoading && (
                        <p>
                            Loading stock
                            records...
                        </p>
                    )}

                    {!stockLoading &&
                        stockRecords.length ===
                            0 && (
                            <p>
                                No stock records
                                found.
                            </p>
                        )}

                    {!stockLoading &&
                        stockRecords.length >
                            0 && (
                            <div className="table-container">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>
                                                Medicine
                                            </th>

                                            <th>
                                                Pharmacy
                                            </th>

                                            <th>
                                                Availability
                                            </th>

                                            <th>
                                                Stock Status
                                            </th>

                                            <th>
                                                Quantity
                                            </th>

                                            <th>
                                                Last Updated
                                            </th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        {stockRecords.map(
                                            (
                                                record
                                            ) => (
                                                <tr
                                                    key={
                                                        record.availability_id
                                                    }
                                                >
                                                    <td>
                                                        {
                                                            record.medicine_name
                                                        }
                                                    </td>

                                                    <td>
                                                        {
                                                            record.pharmacy_name
                                                        }
                                                    </td>

                                                    <td>
                                                        {
                                                            record.availability_status
                                                        }
                                                    </td>

                                                    <td>
                                                        {
                                                            record.stock_status
                                                        }
                                                    </td>

                                                    <td>
                                                        {
                                                            record.quantity
                                                        }
                                                    </td>

                                                    <td>
                                                        {
                                                            record.last_updated
                                                                ? new Date(
                                                                      record.last_updated
                                                                  ).toLocaleString()
                                                                : "—"
                                                        }
                                                    </td>
                                                </tr>
                                            )
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        )}
                </div>

                {/* =================================================
                    UC-13 - UPDATE MEDICINE PRICE
                ================================================= */}

                <div className="staff-subsection">
                    <h3>
                        Update Medicine Price
                    </h3>

                    <p>
                        Update the indicative
                        price of a medicine for
                        a pharmacy.
                    </p>

                    <div className="form-grid">
                        <div>
                            <label>
                                Medicine
                            </label>

                            <select
                                value={
                                    selectedPriceMedicine
                                }
                                onChange={(e) =>
                                    handlePriceMedicineChange(
                                        e.target
                                            .value
                                    )
                                }
                            >
                                <option value="">
                                    Select medicine
                                </option>

                                {priceMedicines.map(
                                    (
                                        medicine
                                    ) => (
                                        <option
                                            key={
                                                medicine.medicine_id
                                            }
                                            value={
                                                medicine.medicine_id
                                            }
                                        >
                                            {
                                                medicine.medicine_name
                                            }
                                        </option>
                                    )
                                )}
                            </select>
                        </div>

                        <div>
                            <label>
                                Pharmacy
                            </label>

                            <select
                                value={
                                    selectedPricePharmacy
                                }
                                onChange={(e) =>
                                    handlePricePharmacyChange(
                                        e.target
                                            .value
                                    )
                                }
                                disabled={
                                    !selectedPriceMedicine
                                }
                            >
                                <option value="">
                                    Select pharmacy
                                </option>

                                {pricePharmacies.map(
                                    (
                                        record
                                    ) => (
                                        <option
                                            key={
                                                record.pharmacy_id
                                            }
                                            value={
                                                record.pharmacy_id
                                            }
                                        >
                                            {
                                                record.pharmacy_name
                                            }
                                        </option>
                                    )
                                )}
                            </select>
                        </div>

                        <div>
                            <label>
                                Current Price
                            </label>

                            <input
                                type="text"
                                value={
                                    currentPrice !==
                                    ""
                                        ? `₹ ${currentPrice}`
                                        : ""
                                }
                                readOnly
                                placeholder="—"
                            />
                        </div>

                        <div>
                            <label>
                                New Indicative Price
                            </label>

                            <input
                                type="number"
                                min="0"
                                step="0.01"
                                value={
                                    newPrice
                                }
                                onChange={(e) =>
                                    setNewPrice(
                                        e.target
                                            .value
                                    )
                                }
                                disabled={
                                    !selectedPriceRecord
                                }
                                placeholder="Enter new price"
                            />
                        </div>
                    </div>

                    <div className="button-row">
                        <button
                            onClick={
                                updatePrice
                            }
                            disabled={
                                priceLoading ||
                                !selectedPriceRecord
                            }
                        >
                            Update Price
                        </button>

                        <button
                            onClick={
                                loadPriceRecords
                            }
                            disabled={
                                priceLoading
                            }
                        >
                            Refresh Prices
                        </button>
                    </div>

                    {priceMessage && (
                        <p className="success">
                            {priceMessage}
                        </p>
                    )}

                    {priceError && (
                        <p className="error">
                            {priceError}
                        </p>
                    )}

                    <h3>
                        Current Indicative Price
                        Records
                    </h3>

                    {priceLoading && (
                        <p>
                            Loading price
                            records...
                        </p>
                    )}

                    {!priceLoading &&
                        priceRecords.length ===
                            0 && (
                            <p>
                                No price records
                                found.
                            </p>
                        )}

                    {!priceLoading &&
                        priceRecords.length >
                            0 && (
                            <div className="table-container">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>
                                                Medicine
                                            </th>

                                            <th>
                                                Pharmacy
                                            </th>

                                            <th>
                                                Location
                                            </th>

                                            <th>
                                                Indicative
                                                Price
                                            </th>

                                            <th>
                                                Last Updated
                                            </th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        {priceRecords.map(
                                            (
                                                record
                                            ) => (
                                                <tr
                                                    key={
                                                        record.price_id
                                                    }
                                                >
                                                    <td>
                                                        {
                                                            record.medicine_name
                                                        }
                                                    </td>

                                                    <td>
                                                        {
                                                            record.pharmacy_name
                                                        }
                                                    </td>

                                                    <td>
                                                        {
                                                            record.location
                                                        }
                                                    </td>

                                                    <td>
                                                        {
                                                            record.currency
                                                        }{" "}
                                                        {
                                                            record.amount
                                                        }
                                                    </td>

                                                    <td>
                                                        {
                                                            record.last_updated
                                                                ? new Date(
                                                                      record.last_updated
                                                                  ).toLocaleString()
                                                                : "—"
                                                        }
                                                    </td>
                                                </tr>
                                            )
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        )}
                </div>
            </section>
        );

    // =========================================================
    // MAIN APPLICATION
    // =========================================================

    return (
        <div className="app">
            <header className="header">
                <div>
                    <h1>
                        MedAccess
                    </h1>

                    <p>
                        Medicine information,
                        availability and
                        indicative pharmacy
                        data
                    </p>
                </div>

                <div className="user-area">
                    <span>
                        Logged in as{" "}
                        <strong>
                            {
                                currentUser?.username
                            }
                        </strong>
                    </span>

                    <button
                        className="logout-button"
                        onClick={
                            handleLogout
                        }
                    >
                        Logout
                    </button>
                </div>
            </header>

            <nav className="navigation">
                <button
                    className={
                        view === "patient"
                            ? "nav-active"
                            : ""
                    }
                    onClick={() =>
                        setView(
                            "patient"
                        )
                    }
                >
                    Patient View
                </button>

                <button
                    className={
                        view ===
                        "pharmacist"
                            ? "nav-active"
                            : ""
                    }
                    onClick={() =>
                        setView(
                            "pharmacist"
                        )
                    }
                >
                    Pharmacist Dashboard
                </button>

                <button
                    className={
                        view === "staff"
                            ? "nav-active"
                            : ""
                    }
                    onClick={() =>
                        setView("staff")
                    }
                >
                    Pharmacy Staff
                </button>
                {(currentUser?.role === "Pharmacist" || currentUser?.role === "Administrator") && (
                    <button className={view === "reports" ? "nav-active" : ""} onClick={() => { setView("reports"); loadReports(); }}>
                        Report Review
                    </button>
                )}
            </nav>

            <main>
                {view === "patient" &&
                    renderPatientView()}

                {view ===
                    "pharmacist" &&
                    renderPharmacistView()}

                {view === "staff" &&
                    renderStaffView()}

                {view === "reports" &&
                    (currentUser?.role === "Pharmacist" || currentUser?.role === "Administrator") &&
                    renderReportsView()}
            </main>

            <footer className="footer">
                <strong>
                    Information only:
                </strong>{" "}
                MedAccess provides medicine
                information and indicative
                pharmacy data. It does not
                dispense or sell medicines.
            </footer>
        </div>
    );
}

export default App;