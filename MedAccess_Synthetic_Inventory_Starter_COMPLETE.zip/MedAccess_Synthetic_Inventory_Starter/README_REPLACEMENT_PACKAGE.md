# MedAccess Synthetic Inventory Starter — Complete Folder

This folder contains the original starter assets and the shared-products V2 generator.

## Required local input

Copy your exported CDCI `catalogue_search` CSV into this folder and name it exactly `cdci_catalogue.csv`. It must include `product_identifier` and `product_name` headers. Recommended additional headers: `brand_identifier`, `brand_name`, `generic_identifier`, `generic_name`, `strength`, `dosage_form`, and `pack_size`.

The package does not include your personal CDCI export. Do not create a fake CSV or use a placeholder database as catalogue input.

## Generate V2 on Windows

Open Command Prompt in this folder and run:

```bat
py scripts\generate_synthetic_inventory_v2.py --catalogue-csv cdci_catalogue.csv --out medaccess_cdci_inventory_v2.db --seed 20260914 --product-pool-size 120 --min-pharmacies 5 --max-pharmacies 10
```

This creates a new `medaccess_cdci_inventory_v2.db` and refuses to overwrite an existing file. Keep your currently working `medaccess_cdci_inventory.db` unchanged and backed up until V2 is verified and the Stage 2 backend is deliberately configured to use it.

## Expected V2 properties

- 20 fictional pharmacies across 6 cities and 8 districts
- 120 distinct CDCI product identifiers (requires at least 120 unique product identifiers in the CSV)
- Each selected product assigned to 5–10 pharmacies
- Synthetic prices, quantities, stock statuses and timestamps
- No live pharmacy connection

`identifier_linked` means the CDCI identifier was copied into a synthetic inventory record. It does not verify authenticity, real stock, price accuracy, clinical equivalence, or substitutability.

## Verify in DB Browser for SQLite

```sql
SELECT COUNT(*) AS pharmacies,
       COUNT(DISTINCT city) AS cities,
       COUNT(DISTINCT district) AS districts
FROM pharmacies;
```
Expected: 20, 6, 8.

```sql
SELECT COUNT(*) AS inventory_rows,
       COUNT(DISTINCT cdci_product_identifier) AS unique_products
FROM inventory_items;
```
Expected unique products: 120; inventory rows should be at least 600.

```sql
SELECT MIN(pharmacy_count) AS min_pharmacies,
       MAX(pharmacy_count) AS max_pharmacies
FROM (
  SELECT cdci_product_identifier,
         COUNT(DISTINCT pharmacy_id) AS pharmacy_count
  FROM inventory_items
  GROUP BY cdci_product_identifier
);
```
Expected min/max: 5 and 10.

```sql
PRAGMA foreign_key_check;
```
Expected: no rows.

## Contents and boundary

- `scripts/generate_synthetic_inventory.py` — original sparse generator.
- `scripts/generate_synthetic_inventory_v2.py` — shared-products generator.
- `sql/schema.sql` — schema.
- `docs/ARCHITECTURE.md` — architecture/cutover notes.
- `medaccess_synthetic_inventory.db` — original starter database, not the V2 database.
- README files — instructions.

This is the data-generation starter, not the full MedAccess Stage 2 app. It does not automatically connect V2 to the running backend/frontend.
