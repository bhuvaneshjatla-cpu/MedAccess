# MedAccess synthetic inventory v2 — shared products

This generator creates a **new** SQLite database designed for cross-pharmacy comparisons. It keeps the existing 20 fictional pharmacies across 6 cities and 8 districts, selects a repeatable pool of 120 CDCI products, and assigns each product to 5–10 distinct pharmacies by default.

All pharmacy identities, addresses, quantities, prices and timestamps are synthetic demo data. CDCI identifier linkage is not clinical verification, proof of authenticity, or real stock/price availability.

## Before you run it

- Keep the currently working `medaccess_cdci_inventory.db` unchanged.
- Put `cdci_catalogue.csv` (exported from the CDCI `catalogue_search` view, with `product_identifier` and `product_name` columns) in this folder, or pass its path.
- Python 3 is required; no pip packages are needed.
- Output filename must not already exist. The script refuses to overwrite an existing file.

## Windows command

From the main `MedAccess_Synthetic_Inventory_Starter` folder:

```bat
py scripts\generate_synthetic_inventory_v2.py --catalogue-csv cdci_catalogue.csv --out medaccess_cdci_inventory_v2.db --seed 20260914 --product-pool-size 120 --min-pharmacies 5 --max-pharmacies 10
```

Expected scale: 20 pharmacies, 6 cities, 8 districts, 120 unique products and approximately 600–1,200 inventory rows (the exact total is deterministic for the same input CSV and seed). Every selected product should occur at 5–10 pharmacies.

## Verify in DB Browser for SQLite

```sql
SELECT COUNT(*) AS pharmacies,
       COUNT(DISTINCT city) AS cities,
       COUNT(DISTINCT district) AS districts
FROM pharmacies;
```

```sql
SELECT COUNT(*) AS inventory_rows,
       COUNT(DISTINCT cdci_product_identifier) AS unique_products
FROM inventory_items;
```

```sql
SELECT MIN(pharmacy_count) AS min_pharmacies,
       MAX(pharmacy_count) AS max_pharmacies
FROM (
  SELECT cdci_product_identifier, COUNT(DISTINCT pharmacy_id) AS pharmacy_count
  FROM inventory_items
  GROUP BY cdci_product_identifier
);
```

Expected geography: 20, 6, 8. Expected unique product count: 120. Expected min/max pharmacies per product: between 5 and 10. Check `PRAGMA foreign_key_check;` returns no rows.

## Switch only after verification

This file is a new database and is **not automatically connected to the running Stage 2 app**. Do not rename it over the existing inventory database. After verification, stop the backend and make a backup before changing the configured database path. Test product lookup, zero-result lookup, out-of-stock display, and multiple-pharmacy display before considering it active.
