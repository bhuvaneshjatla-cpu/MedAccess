# MedAccess catalogue + inventory architecture

## Goal
CDCI is the primary medicine reference catalogue. A separate MedAccess inventory database stores app-owned pharmacy/inventory records. The old `database/medaccess.db` should not be an active runtime dependency for medicine search or inventory after cutover.

## Components
1. **CDCI reference database (read-only):** product/brand/generic reference identifiers and descriptions; not live stock or verified retail prices.
2. **New inventory database:** fictional pharmacy identities, inventory rows, price/stock history and dataset metadata. Later, approved pharmacy-provided records can replace synthetic rows.
3. **Backend:** catalogue search queries CDCI; inventory queries the new DB by CDCI product identifier; demo responses include `is_synthetic: true` and `data_origin: synthetic_seeded`.
4. **Frontend:** show fictional pharmacy records only with prominent demo labels; never imply real-world proximity, opening status or live availability.

## Link semantics
Prefer the CDCI product identifier for a specific product. Brand/generic IDs can be stored as additional references but should not be used alone to claim that two products are interchangeable. Snapshot fields preserve labels used when a synthetic row was generated. Rows without a CDCI export are explicitly unmatched placeholders.

## Synthetic data rules
- Fixed default seed: `20260914`.
- 20 fictional pharmacies, starting with Chennai/Tambaram and extending to other Tamil Nadu cities.
- Up to 35 products per pharmacy by default.
- Prices, quantities and timestamps are generated only for demo/testing.
- No network calls or real pharmacy data are used by the generator.
- Never use synthetic data for real purchasing, treatment decisions, or current-availability claims.

## Cutover plan
1. Back up the old DB outside the active app folder.
2. Keep CDCI catalogue API read-only.
3. Generate a new inventory DB using a CDCI CSV export.
4. Add a separate inventory DB connection and API routes.
5. Update product detail UI to query inventory by CDCI product ID.
6. Test synthetic labels, unmatched products, out-of-stock, low-stock and price variation.
7. Search repository for old medicine-table queries and remove those runtime dependencies from catalogue/inventory flows.
8. Review whether users, reports, reminders or other old records should be migrated; don't silently drop them.
9. Run regression tests for patient/pharmacist/admin workflows.
10. After acceptance, remove old DB from runtime config. Retain backup until approved.

## Future real pharmacy data
Authenticate and authorize staff; restrict staff to approved pharmacy records; audit stock/price changes and update timestamps; validate CSV imports; document the source and freshness of each update. Review CDCI package licensing and attribution before redistribution or production deployment.
