#!/usr/bin/env python3
import argparse, csv, random, sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

SEED_DEFAULT = 20260914
PHARMACIES = [
("Tambaram Demo Pharmacy 01","West Tambaram","Chennai","Chengalpattu"),
("Tambaram Demo Pharmacy 02","East Tambaram","Chennai","Chengalpattu"),
("Chromepet Demo Pharmacy 01","Chromepet","Chennai","Chengalpattu"),
("Pallavaram Demo Pharmacy 01","Pallavaram","Chennai","Chengalpattu"),
("Selaiyur Demo Pharmacy 01","Selaiyur","Chennai","Chengalpattu"),
("Perungalathur Demo Pharmacy 01","Perungalathur","Chennai","Chengalpattu"),
("Sholinganallur Demo Pharmacy 01","Sholinganallur","Chennai","Chengalpattu"),
("Velachery Demo Pharmacy 01","Velachery","Chennai","Chennai"),
("Adyar Demo Pharmacy 01","Adyar","Chennai","Chennai"),
("Guindy Demo Pharmacy 01","Guindy","Chennai","Chennai"),
("T Nagar Demo Pharmacy 01","T Nagar","Chennai","Chennai"),
("Anna Nagar Demo Pharmacy 01","Anna Nagar","Chennai","Chennai"),
("Porur Demo Pharmacy 01","Porur","Chennai","Chennai"),
("Avadi Demo Pharmacy 01","Avadi","Chennai","Tiruvallur"),
("Ambattur Demo Pharmacy 01","Ambattur","Chennai","Tiruvallur"),
("Coimbatore Demo Pharmacy 01","Gandhipuram","Coimbatore","Coimbatore"),
("Madurai Demo Pharmacy 01","Anna Nagar","Madurai","Madurai"),
("Tiruchirappalli Demo Pharmacy 01","Thillai Nagar","Tiruchirappalli","Tiruchirappalli"),
("Salem Demo Pharmacy 01","Fairlands","Salem","Salem"),
("Tirunelveli Demo Pharmacy 01","Palayamkottai","Tirunelveli","Tirunelveli"),
]
SCHEMA = Path(__file__).resolve().parents[1]/"sql"/"schema.sql"

def read_catalogue(path):
    if not path: return []
    rows=[]
    with open(path,encoding="utf-8-sig",newline="") as f:
        for r in csv.DictReader(f):
            def val(*keys):
                for k in keys:
                    v=(r.get(k) or "").strip()
                    if v: return v
                return None
            name=val("product_name","Product Name")
            if name:
                rows.append({"product_identifier":val("product_identifier","Product Identifier"),
                 "product_name":name,"brand_identifier":val("brand_identifier","Brand Identifier"),
                 "brand_name":val("brand_name","Brand Name"),"generic_identifier":val("generic_identifier","Generic Identifier"),
                 "generic_name":val("generic_name","Generic Name"),"strength":val("strength","Strength"),
                 "dosage_form":val("dosage_form","Dose Form"),"pack_size":val("pack_size","Pack Size")})
    return rows

def main():
    ap=argparse.ArgumentParser(description="Create reproducible synthetic MedAccess pharmacy inventory.")
    ap.add_argument("--out",default="medaccess_synthetic_inventory.db")
    ap.add_argument("--catalogue-csv",help="Optional CSV export from the CDCI catalogue_search view")
    ap.add_argument("--seed",type=int,default=SEED_DEFAULT)
    ap.add_argument("--items-per-pharmacy",type=int,default=35)
    ap.add_argument("--history-days",type=int,default=7)
    a=ap.parse_args()
    if a.items_per_pharmacy<1: ap.error("--items-per-pharmacy must be >= 1")
    rng=random.Random(a.seed)
    catalogue=read_catalogue(a.catalogue_csv)
    anchor=datetime(2026,9,14,12,0,0,tzinfo=timezone.utc)
    if catalogue:
        selected=list(catalogue); rng.shuffle(selected)
    else:
        selected=[{"product_identifier":None,"product_name":f"UNMATCHED DEMO PRODUCT {i:03d}",
         "brand_identifier":None,"brand_name":None,"generic_identifier":None,
         "generic_name":"Placeholder — supply CDCI catalogue CSV","strength":None,"dosage_form":None,"pack_size":None}
         for i in range(1,101)]
    out=Path(a.out).resolve(); out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists(): out.unlink()
    conn=sqlite3.connect(out); conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript(SCHEMA.read_text(encoding="utf-8")); cur=conn.cursor()
    for n,(name,loc,city,district) in enumerate(PHARMACIES,1):
        cur.execute("""INSERT INTO pharmacies(pharmacy_id,pharmacy_name,address_line,locality,city,district,state,
        postal_code,latitude,longitude,contact_phone,is_synthetic,created_at)
        VALUES(?,?,?,?,?,?,'Tamil Nadu',NULL,NULL,NULL,NULL,1,?)""",
        (f"DEMO-PH-{n:03d}",name,f"Fictional demo address, {loc}",loc,city,district,anchor.isoformat()))
    for pidx in range(len(PHARMACIES)):
        meds=list(selected); rng.shuffle(meds); meds=meds[:min(a.items_per_pharmacy,len(meds))]
        for j,m in enumerate(meds,1):
            item=f"DEMO-INV-{pidx+1:03d}-{j:04d}"
            qty=rng.choice([0,0,2,4,6,9,12,18,24,36,48,60])
            status="out_of_stock" if qty==0 else ("low_stock" if qty<=5 else "in_stock")
            price=rng.randrange(1200,15001,25)
            updated=(anchor-timedelta(minutes=rng.randint(0,a.history_days*24*60))).isoformat()
            linked=bool(m["product_identifier"])
            cur.execute("""INSERT INTO inventory_items(inventory_item_id,pharmacy_id,cdci_source,cdci_product_identifier,
            cdci_brand_identifier,cdci_generic_identifier,product_name_snapshot,brand_name_snapshot,generic_name_snapshot,
            strength_snapshot,dosage_form_snapshot,pack_size_snapshot,quantity_available,stock_status,price_inr_paise,
            currency,last_updated_at,data_origin,is_synthetic,catalogue_match_status,created_at)
            VALUES(?,?,'NRCeS Common Drug Codes for India',?,?,?,?,?,?,?,?,?,?,?,?, 'INR',?,'synthetic_seeded',1,?,?)""",
            (item,f"DEMO-PH-{pidx+1:03d}",m["product_identifier"],m["brand_identifier"],m["generic_identifier"],
             m["product_name"],m["brand_name"],m["generic_name"],m["strength"],m["dosage_form"],m["pack_size"],
             qty,status,price,updated,"identifier_linked" if linked else "unmatched",anchor.isoformat()))
            cur.execute("INSERT INTO inventory_price_history VALUES(?,?,?,?, 'synthetic_seeded',1)",
             (f"DEMO-PRICE-{pidx+1:03d}-{j:04d}",item,price,updated))
            cur.execute("INSERT INTO inventory_stock_history VALUES(?,?,?,?, 'synthetic_seeded',1)",
             (f"DEMO-STOCK-{pidx+1:03d}-{j:04d}",item,qty,updated))
    meta={"dataset_name":"MedAccess synthetic pharmacy inventory","dataset_kind":"synthetic_demo_only",
     "seed":str(a.seed),"created_at_demo_anchor_utc":anchor.isoformat(),"generator_version":"1.0",
     "pharmacy_count":str(len(PHARMACIES)),"items_per_pharmacy_requested":str(a.items_per_pharmacy),
     "catalogue_csv_supplied":"yes" if catalogue else "no",
     "warning":"All pharmacy names, addresses, prices, quantities and timestamps are synthetic demo data; not live or verified."}
    cur.executemany("INSERT INTO dataset_metadata VALUES (?,?)",meta.items())
    conn.commit()
    counts={"pharmacies":conn.execute("SELECT COUNT(*) FROM pharmacies").fetchone()[0],
     "inventory_items":conn.execute("SELECT COUNT(*) FROM inventory_items").fetchone()[0],
     "identifier_linked_rows":conn.execute("SELECT COUNT(*) FROM inventory_items WHERE catalogue_match_status='identifier_linked'").fetchone()[0],
     "unmatched_rows":conn.execute("SELECT COUNT(*) FROM inventory_items WHERE catalogue_match_status='unmatched'").fetchone()[0],
     "seed":a.seed,"output":str(out),"warning":meta["warning"]}
    conn.close(); print(counts)

if __name__=="__main__": main()
