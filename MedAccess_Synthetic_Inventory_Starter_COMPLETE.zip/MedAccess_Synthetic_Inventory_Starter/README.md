# MedAccess Synthetic Pharmacy Inventory Starter

## Purpose
Creates a **separate SQLite inventory database**. It does not read, change, or depend on the old `database/medaccess.db`. All generated pharmacy identities, addresses, stock quantities, prices, and timestamps are synthetic demo data.

## Contents
- `sql/schema.sql` — new inventory schema.
- `scripts/generate_synthetic_inventory.py` — deterministic generator (Python standard library only).
- `docs/ARCHITECTURE.md` — target architecture and cutover guidance.

## Requirements
Python 3.9+; no third-party Python packages.

## Quick start
```bash
python scripts/generate_synthetic_inventory.py --out medaccess_synthetic_inventory.db --seed 20260914 --items-per-pharmacy 35
```
Creates 20 fictional pharmacies and up to 700 inventory rows. Without a CDCI export, catalogue products are explicitly unmatched placeholders; do not present those placeholders as actual CDCI products.

## Use actual CDCI identifiers
Export CSV from your CDCI staging DB's `catalogue_search` view with columns such as `product_identifier`, `product_name`, `brand_identifier`, `brand_name`, `generic_identifier`, `generic_name`, `strength`, `dosage_form`, `pack_size`. Then run:
```bash
python scripts/generate_synthetic_inventory.py --catalogue-csv .\cdci_catalogue_export.csv --out .\medaccess_synthetic_inventory.db --seed 20260914 --items-per-pharmacy 35
```
The generator marks rows with a supplied product identifier as `identifier_linked`. That means only that a catalogue identifier was supplied; it is not clinical verification or proof of equivalence. Missing strength/form fields remain blank instead of being guessed.

## Reproducibility
The default seed is `20260914`. With the same CSV, generator version, seed, and options, generated assignments/values repeat. Demo timestamps use a fixed UTC anchor. Change `--seed` to create a different stable dataset.

## Validation queries
```sql
SELECT COUNT(*) AS pharmacies FROM pharmacies;
SELECT COUNT(*) AS inventory_rows FROM inventory_items;
SELECT pharmacy_name, city, district FROM pharmacies ORDER BY pharmacy_id;
SELECT pharmacy_name, product_name, quantity_available, stock_status,
       price_inr_paise / 100.0 AS price_inr, is_synthetic, catalogue_match_status
FROM v_demo_inventory ORDER BY pharmacy_name, product_name LIMIT 30;
SELECT * FROM dataset_metadata;
```

## Integration boundary
This is a database/data starter, not a completed frontend/backend integration. To connect it, add a separate inventory DB connection and API routes; keep CDCI read-only; make responses carry a visible synthetic-data indicator; remove old medicine-table runtime dependencies from catalogue/inventory flows. Migrate any useful accounts, reports, reminders, or other records only after reviewing them. Keep a backup outside the active app folder until regression tests pass. Do not claim actual pharmacy availability until data is supplied and verified by a pharmacy.
